import json,pathlib,csv,statistics,sys,hashlib
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'tools'));from teaching_diagnostic_jobs import parameter_names
root=pathlib.Path('/tmp/stanli-teaching-perf/residual-cb58');out=root/'sampling';source=root.parent/'teaching-v6.tsv.run';jobs=[];stats=[]
run_id=hashlib.sha256((out/'identity.json').read_bytes()).hexdigest()[:16]
for r in json.loads((out/'results.json').read_text()):
 n=r['model'];files={e:[] for e in ['stanli','cmdstan']};params=set(parameter_names((source/n/(n+'.hpp')).read_text()));columns=None
 for e in r['sampling']:
  p=out/e['stdout'] if e['engine']=='stanli' else out/(n+'-cmdstan-'+str(e['seed'])+'.csv')
  if not p.exists():continue
  with p.open() as f:
   try:rows=list(csv.DictReader(line for line in f if line.strip() and not line.startswith('#')))
   except Exception:rows=[]
  # A killed process can leave the last row incomplete. Keep only complete rows
  # for partial-chain descriptive counts; do not call it a complete fit.
  rows=[x for x in rows if all(x.values())]
  if not rows:stats.append(dict(model=n,engine=e['engine'],seed=e['seed'],status=e['status'],rows=0));continue
  if columns is None:columns=[x for x in rows[0] if x.split('.')[0] in params]
  get=lambda k:[float(x[k]) for x in rows]
  stats.append(dict(model=n,engine=e['engine'],seed=e['seed'],status=e['status'],rows=len(rows),divergences=sum(get('divergent__')),depth_hits=sum(x>=10 for x in get('treedepth__')),mean_leapfrogs=statistics.mean(get('n_leapfrog__')),lp_range=[min(get('lp__')),max(get('lp__'))],stepsize=get('stepsize__')[0],elapsed_s=e['elapsed_s']))
  if e['status']=='ok':files[e['engine']].append(str(p))
 jobs.append(dict(model=n,run_id=run_id,columns=columns,constants={},files=files))
(root/'diagnostic-jobs.json').write_text(json.dumps(jobs,indent=2)+'\n');(root/'chain-work.json').write_text(json.dumps(stats,indent=2)+'\n')
for s in stats: print(s)
