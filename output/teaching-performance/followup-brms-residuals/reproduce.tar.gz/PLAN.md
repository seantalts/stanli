# Remaining brms gaps, current cb58eb22

Prior CI completed successfully. No other local measurement/build is active.
No runtime changes in this pass. Use current verified production executable,
frozen v6 inputs/CmdStan binaries, seeds 1-4, 1000 warmup +1000 draws, one
no-argument prelaunch, full CLI including Stanli source compilation. Preserve
min(3x same-seed CmdStan,900s) caps. One fixed five-model diagnostic survey;
no reruns until a desired sign. Keep raw results separate from v6 and COM.

Models: sw_re_negbin, s2_mixture_theta, s2_gev, sw_asymlaplace,
s2_zi_asymlaplace. First two distinguish trajectory work/diagnostics from
throughput. Last three determine remaining gaps after generic COM changes.
After all timing finishes, compute per-chain divergences, leapfrogs, depth
hits and established posterior diagnostics. Record next bounded hypothesis
from results. Do not tune sampler, inputs, tolerance, or Stan Math sources.
