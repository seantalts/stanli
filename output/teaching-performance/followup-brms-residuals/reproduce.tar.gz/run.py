import pathlib,sys,subprocess,json
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'harnesses'));import corpus_bench as b
root=pathlib.Path('/tmp/stanli-teaching-perf/residual-cb58');out=root/'sampling';out.mkdir(exist_ok=False)
source=root.parent/'teaching-v6.tsv.run';runner=b.Runner(out);cli=repo/'build-teaching-residual/stanli_run'
models=['sw_re_negbin','s2_mixture_theta','s2_gev','sw_asymlaplace','s2_zi_asymlaplace']
patch=subprocess.check_output(['git','diff','HEAD','--binary']);assert not patch
identity=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),stanli_binary=b.sha(cli),models=models,seeds=[1,2,3,4],warmup=1000,samples=1000,relative_cap=3,absolute_cap=900,source_run='fd5e0ecacddc7047',thread_env=b.THREAD_ENV,inputs={},preconditioning='One no-argument launch per executable; full CLI including Stanli source compilation; no model compilation for CmdStan. One fixed survey, not a repeated confirmation.')
runner.run('prelaunch/stanli',[str(cli)],60);records=[]
for n in models:
 stan=source/'inputs'/(n+'.stan');data=source/'inputs'/(n+'.json');exe=source/n/n
 identity['inputs'][n]=dict(stan=b.sha(stan),data=b.sha(data),cmdstan_executable=b.sha(exe));b.atomic_json(out/'identity.json',identity)
 runner.run('prelaunch/'+n,[str(exe)],60);events=[]
 for seed in identity['seeds']:
  reference=None
  for engine in ['cmdstan','stanli']:
   limit=b.sampling_limit(engine,900,3,reference)
   if limit is None:raise RuntimeError('CmdStan reference did not finish')
   csv=out/(n+'-cmdstan-'+str(seed)+'.csv')
   cmd=[str(exe),'sample','num_warmup=1000','num_samples=1000','random','seed='+str(seed),'data','file='+str(data),'output','file='+str(csv)] if engine=='cmdstan' else [str(cli),str(stan),str(data),'--warmup','1000','--samples','1000','--seed',str(seed),'--sampler-stats']
   ev=runner.run(n+'/sample/'+str(seed)+'/'+engine,cmd,limit)
   if ev['status']=='ok':
    try:b.validate_draws(csv if engine=='cmdstan' else out/ev['stdout'],1000)
    except b.PhaseFailure as ex:ev=dict(ev,status='failed',validation_error=str(ex))
   events.append(dict(engine=engine,seed=seed,**ev));print(n,seed,engine,ev['status'],round(ev['elapsed_s'],6),flush=True)
   if engine=='cmdstan':reference=ev
   b.atomic_json(out/(n+'-events.json'),events)
 records.append(dict(model=n,sampling=events,summary=b.summarize_sampling(events,identity['seeds'])))
 b.atomic_json(out/'results.json',records)
assert b.sha(cli)==identity['stanli_binary']
print('Complete',flush=True)
