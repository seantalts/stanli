from pathlib import Path
import sys,json,gzip,subprocess,hashlib
sys.path.insert(0,'tools')
from verify_refs import parse_status,parse_wa
from report_rethinking_numerics import errors
root=Path('/tmp/stanli-teaching-perf/com-80')
refs=json.loads(gzip.decompress(Path('docs/corpus-refs.json.gz').read_bytes()))
check=Path('build-teaching-residual/stanli_check').resolve();fresh_ref=root.parent/'gaps-v8/com-reference/ref'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'checker_sha256':sha(check),'reference_sha256':sha(Path('docs/corpus-refs.json.gz')),'reference_toolchain':refs['recorded'],'com_write_array_reference_sha256':sha(fresh_ref),'models':{}}
for n in ['s2_com_poisson','sw_asymlaplace','s2_zi_asymlaplace']:
 points={};combined={g:{'count':0,'max_absolute':0,'max_ulp':0} for g in ['log_density','gradient','outputs']}
 for point in ['0','1','2']:
  ref=refs['models'][n]['points'][point]
  if 'wa' not in ref:
   fresh=subprocess.run([str(fresh_ref),'tests/brms/'+n+'.json',point],text=True,capture_output=True,timeout=30,check=True)
   status=parse_status(fresh.stdout);wa=parse_wa(fresh.stdout)
   assert list(map(float,status[1:]))==list(map(float,ref['values']))
   ref=dict(ref,wa=dict(names=wa[0],values=wa[1]))
  proc=subprocess.run([str(check),'tests/brms/'+n+'.stan','tests/brms/'+n+'.json','--point',point,'--wa-values'],text=True,capture_output=True,timeout=30,check=True)
  status=parse_status(proc.stdout);wa=parse_wa(proc.stdout)
  assert status[0]=='OK' and wa[0]==ref['wa']['names']
  rv=list(map(float,ref['values']));ov=list(map(float,status[1:]))
  groups={'log_density':(rv[:1],ov[:1]),'gradient':(rv[1:],ov[1:]),'outputs':(list(map(float,ref['wa']['values'])),list(map(float,wa[1])))}
  points[point]={}
  for g,(a,b) in groups.items():
   stats=errors(a,b);points[point][g]=dict(reference=a,stanli=b,**stats)
   combined[g]['count']+=stats['count']
   for metric in ['max_absolute','max_ulp']:combined[g][metric]=max(combined[g][metric],stats[metric])
 result['models'][n]=dict(summary=combined,points=points)
 print(n,json.dumps(combined))
(root/'final-numerics.json').write_text(json.dumps(result,indent=2)+'\n')
