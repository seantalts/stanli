import pathlib,sys,subprocess,json,shutil,hashlib,os,statistics
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'harnesses'));import corpus_bench as b
root=pathlib.Path('/tmp/stanli-teaching-perf/com-80');source=root.parent/'teaching-v6.tsv.run';out=root/'confirmation-final';out.mkdir(exist_ok=False);runner=b.Runner(out)
cli=out/'stanli-run';shutil.copy2(repo/'build-teaching-residual/stanli_run',cli)
exe=root.parent/'gaps-v8/com-reference/s2_com_poisson';n='s2_com_poisson';stan=source/'inputs'/(n+'.stan');data=source/'inputs'/(n+'.json');before=root/'stanli_run-before'
patch=subprocess.check_output(['git','diff','HEAD','--binary']);(out/'candidate.patch').write_bytes(patch)
identity=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),diff_sha256=hashlib.sha256(patch).hexdigest(),binaries={str(p):b.sha(p) for p in [cli,exe,before]},models=[n],seeds=[1,2,3,4],replicates=3,warmup=1000,samples=1000,relative_cap=3,absolute_cap=900,source_run='fd5e0ecacddc7047',thread_env=b.THREAD_ENV,inputs=dict(stan=b.sha(stan),data=b.sha(data)),preconditioning='One no-argument launch per executable; whole CLI and Stanli source compilation included. Three fixed confirmation blocks. CmdStan first for cap; Stanli baseline/candidate alternate order.')
b.atomic_json(out/'identity.json',identity);events=[]
for p in [cli,exe,before]:runner.run('prelaunch/'+p.name,[str(p)],60)
for rep in range(3):
 for seed in identity['seeds']:
  reference=None;arms=['previous','stanli'] if (rep+seed)%2 else ['stanli','previous']
  for engine in ['cmdstan']+arms:
   limit=b.sampling_limit('cmdstan' if engine=='cmdstan' else 'stanli',900,3,reference)
   if limit is None:raise RuntimeError('reference failed')
   csv=out/('cmdstan-'+str(rep)+'-'+str(seed)+'.csv')
   cmd=[str(exe),'sample','num_warmup=1000','num_samples=1000','random','seed='+str(seed),'data','file='+str(data),'output','file='+str(csv)] if engine=='cmdstan' else [str(before if engine=='previous' else cli),str(stan),str(data),'--warmup','1000','--samples','1000','--seed',str(seed),'--sampler-stats']
   ev=runner.run(n+'/sample/'+str(rep)+'/'+str(seed)+'/'+engine,cmd,limit)
   if ev['status']=='ok':b.validate_draws(csv if engine=='cmdstan' else out/ev['stdout'],1000)
   events.append(dict(rep=rep,engine=engine,seed=seed,**ev));print(rep,seed,engine,ev['status'],ev['elapsed_s'],flush=True)
   if engine=='cmdstan':reference=ev
   b.atomic_json(out/'result.json',dict(model=n,sampling=events))
ratios=[]
for rep in range(3):
 c=statistics.median(e['elapsed_s'] for e in events if e['rep']==rep and e['engine']=='cmdstan');s=statistics.median(e['elapsed_s'] for e in events if e['rep']==rep and e['engine']=='stanli');ratios.append(c/s)
print('block ratios',ratios,flush=True)
