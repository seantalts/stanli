import pathlib,subprocess,os,json,statistics,hashlib
root=pathlib.Path('/tmp/stanli-teaching-perf/com-80');run=root.parent/'teaching-v6.tsv.run';previous=root/'bench_grad-before';candidate=pathlib.Path('build-teaching-residual/bench_grad').resolve();rows=[]
env={**os.environ,**{x:'1' for x in ['OMP_NUM_THREADS','STAN_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS']}}
identity=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),patch=subprocess.check_output(['git','diff','HEAD','--binary'],text=True),binaries={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [previous,candidate]},thread_env={k:env[k] for k in ['OMP_NUM_THREADS','STAN_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS']})
(root/'final-canary-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
for model in ['s2_com_poisson','sw_asymlaplace','s2_gev','ch14_m14_8']:
 for rep in range(5):
  for arm in (['before','after'] if rep%2==0 else ['after','before']):
   exe=previous if arm=='before' else candidate
   cmd=[str(exe),str(run/model/'model.sexp'),str(run/'inputs'/(model+'.json')),'--timed','--warmup-ms','200','--measure-ms','400']
   p=subprocess.run(cmd,env=env,text=True,capture_output=True,check=True);row=dict(model=model,rep=rep,arm=arm,argv=cmd,result=json.loads(p.stdout));rows.append(row)
 vals=[r['result']['values'] for r in rows if r['model']==model];assert all(x==vals[0] for x in vals)
 print(model,{arm:statistics.median(r['result']['elapsed_ns']/r['result']['iterations']/1000 for r in rows if r['model']==model and r['arm']==arm) for arm in ['before','after']},flush=True)
 (root/'final-canary-pairs.json').write_text(json.dumps(rows,indent=2)+'\n')
