r <- '/tmp/stanli-teaching-perf/com-80'
a <- readRDS(file.path(r,'before-points.rds')); b <- readRDS(file.path(r,'after-points.rds'))
stopifnot(identical(a,b,num.eq=FALSE))
refs <- jsonlite::fromJSON('/tmp/stanli-teaching-perf/com-cap/extra-point-refs.json',simplifyVector=FALSE)
results <- lapply(seq_along(b), function(i) {
 lines <- strsplit(refs[[i]]$stdout,'\n')[[1]]
 v <- scan(text=sub('^OK ', '',lines[1]),quiet=TRUE)
 wa <- scan(text=sub('^WAVALS ', '',lines[startsWith(lines,'WAVALS ')]),quiet=TRUE)
 actual <- c(b[[i]]$lp,b[[i]]$gradient)
 stopifnot(length(wa)==length(b[[i]]$outputs))
 list(q=b[[i]]$q,lp_abs=abs(actual[1]-v[1]),grad_max_abs=max(abs(actual[-1]-v[-1])),output_max_abs=max(abs(b[[i]]$outputs-wa)),stanli_hex=sprintf('%a',actual),cmdstan_hex=sprintf('%a',v),outputs_hex=sprintf('%a',b[[i]]$outputs),cmdstan_outputs_hex=sprintf('%a',wa))
})
summary <- list(points=length(b),before_after_bitwise_identical=TRUE,max_lp_abs=max(sapply(results,`[[`,'lp_abs')),max_gradient_abs=max(sapply(results,`[[`,'grad_max_abs')),max_output_abs=max(sapply(results,`[[`,'output_max_abs')),points_detail=results)
jsonlite::write_json(summary,file.path(r,'extra-point-numerics.json'),auto_unbox=TRUE,pretty=TRUE,digits=NA)
print(summary[1:5])
