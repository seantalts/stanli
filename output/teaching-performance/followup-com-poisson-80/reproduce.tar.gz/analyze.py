from pathlib import Path
import json,statistics,hashlib,sys
r=Path('/tmp/stanli-teaching-perf/com-80');run=r/'confirmation-final';events=json.loads((run/'result.json').read_text())['sampling']
med=statistics.median
summary={'protocol':json.loads((run/'identity.json').read_text()),'blocks':[],'seeds':[],'csv_comparisons':[],'all_successful':all(e['status']=='ok' for e in events)}
for rep in range(3):
 times={a:med(e['elapsed_s'] for e in events if e['rep']==rep and e['engine']==a) for a in ['cmdstan','previous','stanli']}
 summary['blocks'].append(dict(rep=rep,median_seconds=times,speedup=times['cmdstan']/times['stanli'],before_speedup=times['cmdstan']/times['previous']))
 for seed in range(1,5):
  rows=[next(e for e in events if e['rep']==rep and e['seed']==seed and e['engine']==a) for a in ['previous','stanli']];files=[run/e['stdout'] for e in rows];same=files[0].read_bytes()==files[1].read_bytes();assert same
  summary['csv_comparisons'].append(dict(rep=rep,seed=seed,identical=same,sha256=[hashlib.sha256(p.read_bytes()).hexdigest() for p in files]))
for seed in range(1,5):
 vals={a:[e['elapsed_s'] for e in events if e['seed']==seed and e['engine']==a] for a in ['cmdstan','previous','stanli']};times={a:med(v) for a,v in vals.items()};ratios=[next(e['elapsed_s'] for e in events if e['seed']==seed and e['rep']==rep and e['engine']=='cmdstan')/next(e['elapsed_s'] for e in events if e['seed']==seed and e['rep']==rep and e['engine']=='stanli') for rep in range(3)]
 summary['seeds'].append(dict(seed=seed,median_seconds=times,speedup=times['cmdstan']/times['stanli'],ratio_range=[min(ratios),max(ratios)],mad_seconds={a:med(abs(x-times[a]) for x in v) for a,v in vals.items()}))
times={a:med(e['elapsed_s'] for e in events if e['engine']==a) for a in ['cmdstan','previous','stanli']}
summary.update(overall_median_seconds=times,overall_ratio_of_medians=times['cmdstan']/times['stanli'],before_ratio_of_medians=times['cmdstan']/times['previous'],stanli_time_reduction=1-times['stanli']/times['previous'],raw=events)
(r/'final-sampling-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
sys.path.insert(0,'tools');from report_rethinking_numerics import errors
points=json.loads((r/'extra-point-numerics.json').read_text());groups={g:{'reference':[],'stanli':[]} for g in ['log_density','gradient','outputs']}
for p in points['points_detail']:
 a=list(map(float.fromhex,p['cmdstan_hex']));b=list(map(float.fromhex,p['stanli_hex']))
 for group,aa,bb in [('log_density',a[:1],b[:1]),('gradient',a[1:],b[1:]),('outputs',list(map(float.fromhex,p['cmdstan_outputs_hex'])),list(map(float.fromhex,p['outputs_hex'])))]:groups[group]['reference']+=aa;groups[group]['stanli']+=bb
points['summary']={g:errors(v['reference'],v['stanli']) for g,v in groups.items()};(r/'extra-point-numerics.json').write_text(json.dumps(points,indent=2)+'\n')
canaries=json.loads((r/'final-canary-pairs.json').read_text());canary_summary={}
for model in dict.fromkeys(x['model'] for x in canaries):
 values={a:[x['result']['elapsed_ns']/x['result']['iterations']/1000 for x in canaries if x['model']==model and x['arm']==a] for a in ['before','after']}
 canary_summary[model]={a:dict(median_us=med(v),mad_us=med(abs(x-med(v)) for x in v),range_us=[min(v),max(v)]) for a,v in values.items()}
(r/'canary-summary.json').write_text(json.dumps(canary_summary,indent=2)+'\n')
print('ratio',summary['overall_ratio_of_medians'],'before',summary['before_ratio_of_medians'],'time reduction',summary['stanli_time_reduction']);print('seeds',summary['seeds']);print('numerics',points['summary']);print('canaries',canary_summary)
