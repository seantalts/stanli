library(stanli)
root <- "/tmp/stanli-teaching-perf/com-80"
points <- jsonlite::fromJSON("/tmp/stanli-teaching-perf/com-cap/extra-points.json")
m <- stanli_model("tests/brms/s2_com_poisson.stan", data="tests/brms/s2_com_poisson.json")
results <- lapply(seq_len(nrow(points)),function(i) { a <- log_prob_grad(m, points[i,]); list(q=points[i,], lp=a$lp, gradient=a$grad, outputs=.Call("stanli_r_write_array",m$ptr,as.double(points[i,]))) })
saveRDS(results,file.path(root,paste0(commandArgs(TRUE)[1],"-points.rds")))
jsonlite::write_json(results,file.path(root,paste0(commandArgs(TRUE)[1],"-points.json")),auto_unbox=TRUE,pretty=TRUE,digits=NA)
cat(length(results),"points evaluated\n")
