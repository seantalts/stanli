library(stanli)
root <- "/tmp/stanli-teaching-perf/com-cap"
points <- jsonlite::fromJSON(file.path(root,"extra-points.json"))
Sys.setenv(STANLI_NO_FILL_SINK="1")
before <- stanli_model("tests/brms/s2_com_poisson.stan", data="tests/brms/s2_com_poisson.json")
Sys.unsetenv("STANLI_NO_FILL_SINK")
after <- stanli_model("tests/brms/s2_com_poisson.stan", data="tests/brms/s2_com_poisson.json")
results <- lapply(seq_len(nrow(points)), function(i) {
  a <- log_prob_grad(before, points[i,]); b <- log_prob_grad(after, points[i,])
  stopifnot(identical(a,b))
  list(q=points[i,],lp=b$lp,gradient=b$grad,identical_before_after=TRUE)
})
jsonlite::write_json(results,file.path(root,"extra-point-stanli.json"),auto_unbox=TRUE,pretty=TRUE,digits=NA)
cat(length(results),"points: identical before/after\n")
