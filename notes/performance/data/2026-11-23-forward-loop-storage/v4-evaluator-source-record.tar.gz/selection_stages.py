import argparse, concurrent.futures, hashlib, json, pathlib, shutil, subprocess, sys, tempfile, time
REPO=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(REPO/'tools'))
import bench_select as bs
from corpus_inventory import corpus_cases,materialize_data
ap=argparse.ArgumentParser();ap.add_argument('--arm',required=True,choices=bs.ARMS);ap.add_argument('--build',required=True,type=pathlib.Path);ap.add_argument('--out',required=True,type=pathlib.Path);ap.add_argument('--jobs',type=int,default=1)
a=ap.parse_args();a.out=a.out.resolve();a.out.mkdir(parents=True,exist_ok=True)
tools=bs.arm_tools(a.build);identity=bs.identity(tools)
identity['tracked_diff_sha256']=hashlib.sha256(subprocess.check_output(['git','diff','HEAD','--binary'],cwd=tools['source'])).hexdigest()
identity['harness_sha256']=bs.sha(REPO/'tools/bench_select.py')
record_path=a.out/f'{a.arm}-programs.json'
if record_path.exists():
 old=json.loads(record_path.read_text())
 if old['identity']!=identity:raise SystemExit('arm identity changed; use fresh output directory')
 records=old['records']
else:records={}
cases=corpus_cases('/Users/xitrium/claud/stanrt/deps/posteriordb','all')
inputs=a.out/'inputs';inputs.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory() as cache:
 for name,case in cases.items():
  dest=inputs/f'{name}.json';src=materialize_data(case,cache)
  if dest.exists():
   if bs.sha(dest)!=bs.sha(src):raise SystemExit('input changed: '+name)
  else:shutil.copyfile(src,dest)
context={'identity':identity,'records':records,'models':list(cases)}
def write_record():
 temp=record_path.with_suffix('.tmp');temp.write_text(json.dumps(context,indent=1,sort_keys=True)+'\n');temp.replace(record_path)
write_record()
original_run=bs.run_process
commands=a.out/'commands'/a.arm;commands.mkdir(parents=True,exist_ok=True)
def logged(argv,timeout):
 start=time.time();result,error=original_run(argv,timeout)
 key=hashlib.sha256('\0'.join(map(str,argv)).encode()).hexdigest()[:24]
 event={'argv':list(map(str,argv)),'timeout':timeout,'started':start,'elapsed_s':time.time()-start,'error':error}
 if result is not None:
  event.update(returncode=result.returncode,stderr=result.stderr,stdout_sha256=hashlib.sha256(result.stdout.encode()).hexdigest(),stdout_bytes=len(result.stdout.encode()))
  if result.returncode:event['stdout_failure_tail']=result.stdout[-8000:]
 (commands/(key+'.json')).write_text(json.dumps(event,indent=1)+'\n')
 return result,error
bs.run_process=logged
names=[n for n in cases if n not in records]
print(f'{a.arm}: {len(cases)} corpus cases, {len(records)} cached, {len(names)} pending',flush=True)
for name in names:
 (a.out/f'{a.arm}-status.json').write_text(json.dumps({'current':name,'done':len(records),'total':len(cases),'failures':sum(bool(v['failure']) for v in records.values()),'started':time.time()}))
 start=time.time();program,failure=bs.prepare(a.arm,tools,name,cases[name].source,inputs/f'{name}.json',a.out)
 # Full program text is already retained in the standard model directories;
 # avoid copying multi-megabyte dumps into the status index.
 records[name]={'failure':failure,'elapsed_s':time.time()-start,'mir_sha256':program['mir'] if program else None,'source_sha256':bs.sha(cases[name].source),'data_sha256':bs.sha(inputs/f'{name}.json')}
 write_record()
 print(f'{a.arm} {len(records)}/{len(cases)} {name}: {failure or "ok"} ({time.time()-start:.3f}s)',flush=True)
if bs.identity(tools)!={k:v for k,v in identity.items() if k not in ['tracked_diff_sha256','harness_sha256']}:
 raise SystemExit('arm binaries/source identity changed during program preparation')
(a.out/f'{a.arm}-status.json').write_text(json.dumps({'done':len(records),'total':len(cases),'failures':sum(bool(v['failure']) for v in records.values()),'complete':True}))
print(f'{a.arm} completed; failures={sum(bool(v["failure"]) for v in records.values())}',flush=True)
