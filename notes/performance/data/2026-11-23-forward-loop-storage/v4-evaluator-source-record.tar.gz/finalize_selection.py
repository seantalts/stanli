import argparse,hashlib,json,math,pathlib,subprocess,sys,time
REPO=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(REPO/'tools'))
import bench_select as bs
ap=argparse.ArgumentParser();ap.add_argument('--out',required=True,type=pathlib.Path);ap.add_argument('--base',required=True,type=pathlib.Path);ap.add_argument('--candidate',required=True,type=pathlib.Path);a=ap.parse_args();a.out=a.out.resolve()
arms={arm:bs.arm_tools(getattr(a,arm)) for arm in bs.ARMS};indexes={arm:json.loads((a.out/f'{arm}-programs.json').read_text()) for arm in bs.ARMS}
for arm in bs.ARMS:
 current=bs.identity(arms[arm]);old=indexes[arm]['identity'];expected={k:v for k,v in old.items() if k not in ['tracked_diff_sha256','harness_sha256']}
 if current!=expected:raise SystemExit(f'{arm} identity changed since program screen')
names=indexes['base']['models'];assert names==indexes['candidate']['models']
failures={};changes={};opcode_users={};opcodes=['LOOP']
for name in names:
 for arm in bs.ARMS:
  error=indexes[arm]['records'][name]['failure']
  if error:failures[name]='; '.join(filter(None,[failures.get(name),error]))
 if name in failures:continue
 programs={}
 for arm in bs.ARMS:
  p=a.out/arm/name
  programs[arm]={'mir':indexes[arm]['records'][name]['mir_sha256'],'ops':(p/'ops.txt').read_text(),'wa_ops':(p/'wa_ops.txt').read_text(),'islands':(p/'islands.txt').read_text()}
 change=bs.program_change(programs['base'],programs['candidate'])
 if change:changes[name]=change
 used=sorted({u for arm in bs.ARMS for u in bs.program_opcodes(programs[arm],opcodes)})
 if used:opcode_users[name]=used
prepared=[n for n in names if n not in failures]
print(f'program comparisons complete: {len(names)} total, {len(changes)} changed, {len(opcode_users)} LOOP users, {len(failures)} failures',flush=True)
original_run=bs.run_process
prep_log=(a.out/'preparation-processes.jsonl').open('a')
def logged_prep(argv,timeout):
 start=time.time();result,error=original_run(argv,timeout)
 event={'argv':list(map(str,argv)),'timeout':timeout,'started':start,'elapsed_s':time.time()-start,'error':error}
 if result is not None:event.update(returncode=result.returncode,stdout=result.stdout,stderr=result.stderr)
 prep_log.write(json.dumps(event)+'\n');prep_log.flush()
 return result,error
bs.run_process=logged_prep
times,prep_failures=bs.time_preparation(prepared,arms,{n:a.out/'inputs'/f'{n}.json' for n in names},a.out,3);failures.update(prep_failures)
prep_log.close()
prep_flags={n:f"preparation {t['base_s']*1e3:.1f} -> {t['candidate_s']*1e3:.1f} ms" for n,t in times.items() if bs.prep_regressed(t['base_s'],t['candidate_s'])}
chosen=bs.selection(names,changes,opcode_users,prep_flags,failures,bs.CONTROLS)
ratios=[t['base_s']/t['candidate_s'] for t in times.values() if t['base_s']>0 and t['candidate_s']>0]
report=dict(arms={arm:indexes[arm]['identity'] for arm in bs.ARMS},opcodes=opcodes,controls=list(bs.CONTROLS),prep_reps=3,counts=dict(models=len(names),changed=len(changes),opcode_users=len(opcode_users),prep_timed=len(times),prep_regressed=len(prep_flags),failures=len(failures),selected=len(chosen)),prep_geomean_speedup=math.exp(sum(map(math.log,ratios))/len(ratios)) if ratios else None,changed=changes,opcode_users=opcode_users,prep_regressed=prep_flags,failures=failures,preparation=times,selected=chosen,models=','.join(sorted(chosen)))
(a.out/'selection.json').write_text(json.dumps(report,indent=1,sort_keys=True)+'\n')
print(json.dumps(report['counts']),flush=True)
print('--models '+report['models'],flush=True)
