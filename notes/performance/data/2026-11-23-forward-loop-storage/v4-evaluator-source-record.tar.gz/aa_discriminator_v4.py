import hashlib
import json
import os
import statistics
import subprocess
import sys
import time
from pathlib import Path

out = Path(__file__).resolve().parent
own = out.parents[1]
sys.path.insert(0, str(own.parent / 'stanli-covariance-base/harnesses'))
import corpus_bench as cb

names = ['cm_lba2', 'stanguide_changepoint']
orders = [('base_a', 'candidate', 'base_b'), ('base_b', 'candidate', 'base_a'), ('candidate', 'base_a', 'base_b'),
          ('base_b', 'base_a', 'candidate'), ('base_a', 'base_b', 'candidate'), ('candidate', 'base_b', 'base_a')]
env = os.environ.copy()
env.update({k: '1' for k in ['STAN_NUM_THREADS', 'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS']})
runs = {a: out / 'bench-v4' / (a + '.tsv.run') for a in ('base', 'candidate')}
events = {a: [json.loads(s) for s in (p / 'events.jsonl').read_text().splitlines()] for a, p in runs.items()}
raw, results = [], {}
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(argv, cwd, arm, name, rep, phase):
    start = time.perf_counter()
    r = subprocess.run(argv, cwd=cwd, env=env, capture_output=True, text=True, timeout=300)
    event = {'argv': argv, 'cwd': cwd, 'arm': arm, 'model': name, 'round': rep, 'phase': phase,
             'elapsed_s': time.perf_counter()-start, 'returncode': r.returncode, 'stdout': r.stdout, 'stderr': r.stderr, 'load_average_after': os.getloadavg()}
    raw.append(event)
    assert r.returncode == 0, event
    return event

for name in names:
    work = out / 'v4-aa-discriminator' / name
    work.mkdir(parents=True, exist_ok=False)
    models = {a: json.loads((p / (name + '.result.json')).read_text()) for a, p in runs.items()}
    gradient = {a: next(e for e in events[a] if e['phase'] == name + '/gradient/0/stanli') for a in runs}
    original = {a: json.loads((runs[a] / e['stdout']).read_text().splitlines()[-1]) for a, e in gradient.items()}
    count = models['base']['row']['gradient_count']
    kept = models['base']['gradients'][0]['kept_points']
    rounds = []
    for rep, order in enumerate(orders):
        row = {}
        for arm in order:
            source = 'candidate' if arm == 'candidate' else 'base'
            compile_event = models[source]['setup']['stanli_compile']
            argv = compile_event['argv'].copy()
            mir = work / (arm + '-' + str(rep) + '.sexp')
            argv[argv.index('--output')+1] = str(mir)
            compile_s = run(argv, compile_event['cwd'], arm, name, rep, 'compile')['elapsed_s']
            e = gradient[source]
            assert sha(mir) == sha(e['argv'][1])
            prefix = e['argv'][:e['argv'].index('--timed')]
            prep = run(prefix + ['--prep'], e['cwd'], arm, name, rep, 'prepare')
            prep_s = float(prep['stdout'].splitlines()[-1].split()[0])
            result = run(e['argv'], e['cwd'], arm, name, rep, 'gradient')
            parsed = cb.parse_timing(result['stdout'], 20, 40, 10)
            assert [(p['finite'], p.get('values')) for p in parsed['points']] == [(p['finite'], p.get('values')) for p in original[source]['points']]
            warm = cb.mean_ns(parsed, kept)
            row[arm] = {'compile_s': compile_s, 'prep_s': prep_s, 'warm_ns': warm, 'total_s': compile_s + prep_s + count * warm / 1e9}
        rounds.append(row)
    medians = {a: statistics.median(r[a]['total_s'] for r in rounds) for a in orders[0]}
    base_median = statistics.median(r[a]['total_s'] for r in rounds for a in ('base_a', 'base_b'))
    aa = [r['base_b']['total_s']/r['base_a']['total_s'] for r in rounds]
    ba = [r['candidate']['total_s']/((r['base_a']['total_s']+r['base_b']['total_s'])/2) for r in rounds]
    median_mad = lambda xs: {'median': statistics.median(xs), 'mad': statistics.median(abs(v-statistics.median(xs)) for v in xs)}
    results[name] = {'rounds': rounds, 'median_total_s': medians, 'combined_base_median_s': base_median,
                     'delta_s': medians['candidate']-base_median, 'major_threshold_s': max(.02*base_median, .005),
                     'major_regression_confirmed': medians['candidate']-base_median > max(.02*base_median, .005),
                     'aa_ratios': aa, 'candidate_over_pair_mean_ratios': ba, 'aa_summary': median_mad(aa), 'candidate_over_pair_mean_summary': median_mad(ba)}
    print(name, json.dumps({k:v for k,v in results[name].items() if k != 'rounds'}), flush=True)
    (out / 'v4-aa-discriminator-events.json').write_text(json.dumps(raw, indent=2)+'\n')
    (out / 'v4-aa-discriminator-summary.json').write_text(json.dumps({'purpose': 'prespecified follow-up of two noisy original regressions; original and first follow-up retained', 'orders': orders, 'models': results}, indent=2)+'\n')
