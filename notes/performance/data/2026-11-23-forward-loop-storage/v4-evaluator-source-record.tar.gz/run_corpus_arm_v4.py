import argparse,hashlib,json,os,pathlib,subprocess,sys,time
own=pathlib.Path(__file__).resolve().parents[2];out=own/'.cache/covariance-storage-validation';selection=json.loads((out/'selection-v4/selection.json').read_text())
ap=argparse.ArgumentParser();ap.add_argument('arm',choices=('base','candidate'));a=ap.parse_args()
source=own.parent/('stanli-covariance-base' if a.arm=='base' else 'stanli-covariance-fix')
build=source/'build';deps=pathlib.Path('/Users/xitrium/claud/stanrt/deps')
probe_root=subprocess.check_output(['bash','-c','source tools/stanc_embed/provenance.sh && stanc_embed_dir'],cwd=source,text=True).strip()
benchout=out/'bench-v4';benchout.mkdir(exist_ok=True)
argv=[sys.executable,'harnesses/corpus_bench.py',str(deps/'cmdstan'),str(deps/'posteriordb'),str(benchout/(a.arm+'.tsv')),'--bench',str(build/'bench_grad'),'--vectorize-probe',str(pathlib.Path(probe_root)/'stanli-vectorize-probe'),'--stanc',str(deps/'stanc3/stanc-pinned'),'--points-file',str(own.parent/'stanli-covariance-base/docs/internal/artifacts/benchmark-points.json.gz'),'--corpus','all','--rounds','6','--warmup-ms','20','--measure-ms','40','--points','10','--gradient-timeout','60','--build-timeout','900','--build-jobs','4']
extra_controls=json.loads((out/'selection-v2/selection.json').read_text())['models'].split(',')
benchmark_models=','.join(sorted(set(selection['models'].split(','))|set(extra_controls)))
if not selection['failures']:argv+=['--models',benchmark_models]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta={'argv':argv,'cwd':str(source),'selection_counts':selection['counts'],'full_corpus_required':bool(selection['failures']),'additional_controls':{n:'prior V2 selected model retained for comparability and preparation follow-up' for n in extra_controls if n not in selection['selected']},'benchmark_models':benchmark_models,'bench_sha256':sha(build/'bench_grad'),'source_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'tracked_diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff','HEAD','--binary'],cwd=source)).hexdigest()}
(out/('v4-'+a.arm+'-benchmark-command.json')).write_text(json.dumps(meta,indent=2)+'\n')
start=time.time()
with (out/('v4-'+a.arm+'-benchmark.log')).open('w') as f:r=subprocess.run(argv,cwd=source,stdout=f,stderr=subprocess.STDOUT)
(out/('v4-'+a.arm+'-benchmark-process.json')).write_text(json.dumps({'returncode':r.returncode,'elapsed_s':time.time()-start,'bench_sha256_after':sha(build/'bench_grad')},indent=2)+'\n')
print(a.arm,'corpus benchmark exit',r.returncode,'seconds',time.time()-start,flush=True)
sys.exit(r.returncode)
