import hashlib
import json
import os
import statistics
import subprocess
import sys
import time
from pathlib import Path

out = Path(__file__).resolve().parent
own = out.parents[1]
base = own.parent / 'stanli-covariance-base'
sys.path.insert(0, str(base / 'harnesses'))
import corpus_bench as cb

comparison = json.loads((out / 'v4-comparison.json').read_text())
flagged = [r['model'] for r in comparison['records'] if r['major_regression']]
if not flagged:
    print('No apparent major regressions; no follow-up measurements required.')
    sys.exit(0)
names = sorted(set(flagged) | {'covid19imperial_v3'})
env = os.environ.copy()
env.update({k: '1' for k in ['STAN_NUM_THREADS', 'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS']})
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
runs = {a: out / 'bench-v4' / (a + '.tsv.run') for a in ('base', 'candidate')}
all_events = {a: [json.loads(s) for s in (p / 'events.jsonl').read_text().splitlines()] for a, p in runs.items()}
records = {a: {n: json.loads((p / (n + '.result.json')).read_text()) for n in names} for a, p in runs.items()}
orders = [('base', 'candidate', 'cmdstan'), ('cmdstan', 'candidate', 'base'), ('candidate', 'base', 'cmdstan'),
          ('cmdstan', 'base', 'candidate'), ('base', 'cmdstan', 'candidate'), ('candidate', 'cmdstan', 'base')]
events, measurements = [], {}
def execute(phase, arm, model, rep, argv, cwd, timeout):
    start = time.perf_counter()
    p = subprocess.run(argv, cwd=cwd, env=env, capture_output=True, text=True, timeout=timeout)
    event = {'phase': phase, 'arm': arm, 'model': model, 'round': rep, 'argv': argv, 'cwd': cwd,
             'elapsed_s': time.perf_counter()-start, 'returncode': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}
    events.append(event)
    if p.returncode: raise RuntimeError(event)
    return event

for name in names:
    work = out / 'v4-regression-followup' / name
    work.mkdir(parents=True, exist_ok=False)
    gradient_commands = {}
    originals = {}
    for arm, engine in [('base', 'stanli'), ('candidate', 'stanli'), ('cmdstan', 'cmdstan')]:
        source_arm = 'base' if arm == 'cmdstan' else arm
        e = next(e for e in all_events[source_arm] if e['phase'] == f'{name}/gradient/0/{engine}')
        gradient_commands[arm] = e
        originals[arm] = json.loads((runs[source_arm] / e['stdout']).read_text().splitlines()[-1])
    measurements[name] = []
    for rep, order in enumerate(orders):
        round_record = {'round': rep, 'order': list(order), 'compile_s': {}, 'prep_s': {}, 'warm_ns': {}, 'numerical': {}}
        setup_order = ('base', 'candidate') if rep % 2 == 0 else ('candidate', 'base')
        for arm in setup_order:
            e = records[arm][name]['setup']['stanli_compile']
            argv = e['argv'].copy()
            mir = work / f'{arm}-{rep}.sexp'
            argv[argv.index('--output')+1] = str(mir)
            got = execute('compile', arm, name, rep, argv, e['cwd'], 900)
            round_record['compile_s'][arm] = got['elapsed_s']
            original_mir = Path(gradient_commands[arm]['argv'][1])
            assert sha(mir) == sha(original_mir), 'fresh MIR changed'
        for arm in setup_order:
            e = gradient_commands[arm]
            argv = e['argv'][:e['argv'].index('--timed')] + ['--prep']
            got = execute('prepare', arm, name, rep, argv, e['cwd'], 300)
            round_record['prep_s'][arm] = float(got['stdout'].splitlines()[-1].split()[0])
        pair = {}
        for arm in order:
            e = gradient_commands[arm]
            got = execute('gradient', arm, name, rep, e['argv'], e['cwd'], 60)
            pair[arm] = cb.parse_timing(got['stdout'], 20, 40, 10)
            original_values = [(p['finite'], p.get('values')) for p in originals[arm]['points']]
            current_values = [(p['finite'], p.get('values')) for p in pair[arm]['points']]
            assert original_values == current_values, 'fresh numerical output changed'
        for arm in ('base', 'candidate'):
            checked = cb.check_pair({'stanli': pair[arm], 'cmdstan': pair['cmdstan']}, lp_only=name in cb.LP_ONLY)
            round_record['numerical'][arm] = checked
            round_record['warm_ns'][arm] = cb.mean_ns(pair[arm], checked['kept_points'])
        round_record['warm_ns']['cmdstan'] = cb.mean_ns(pair['cmdstan'], round_record['numerical']['base']['kept_points'])
        count = records['base'][name]['row']['gradient_count']
        round_record['estimated_s'] = {a: round_record['compile_s'][a] + round_record['prep_s'][a] + count * round_record['warm_ns'][a] / 1e9 for a in ('base', 'candidate')}
        measurements[name].append(round_record)
        (out / 'v4-regression-followup-events.json').write_text(json.dumps({'events': events, 'measurements': measurements}, indent=2) + '\n')
    print(name, 'six balanced rounds complete', flush=True)

summary = {'purpose': 'fresh controlled explanation of every apparent major regression; original results retained',
           'flagged_original_models': flagged, 'additional_control': 'covid19imperial_v3', 'orders': orders,
           'protocol': 'unchanged original engine argv/timer; six balanced BASE/FIX/CmdStan rounds; source compilation and prep measured separately', 'models': {}}
for name, rounds in measurements.items():
    total = {a: statistics.median(r['estimated_s'][a] for r in rounds) for a in ('base', 'candidate')}
    delta = total['candidate'] - total['base']
    threshold = max(.02 * total['base'], .005)
    warm = {a: statistics.median(r['warm_ns'][a] for r in rounds) for a in ('base', 'candidate', 'cmdstan')}
    paired_ratios = [r['estimated_s']['candidate'] / r['estimated_s']['base'] for r in rounds]
    ratio = statistics.median(paired_ratios)
    summary['models'][name] = {'median_total_s': total, 'median_warm_ns': warm,
                             'warm_ns_mad': {a: statistics.median(abs(r['warm_ns'][a]-warm[a]) for r in rounds) for a in warm},
                             'median_compile_s': {a: statistics.median(r['compile_s'][a] for r in rounds) for a in total},
                             'median_prep_s': {a: statistics.median(r['prep_s'][a] for r in rounds) for a in total},
                             'paired_total_ratios': paired_ratios, 'median_paired_total_ratio': ratio,
                             'paired_total_ratio_mad': statistics.median(abs(x-ratio) for x in paired_ratios),
                             'delta_s': delta, 'major_threshold_s': threshold, 'major_regression_confirmed': delta > threshold}
    print(name, json.dumps(summary['models'][name]), flush=True)
(out / 'v4-regression-followup-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
