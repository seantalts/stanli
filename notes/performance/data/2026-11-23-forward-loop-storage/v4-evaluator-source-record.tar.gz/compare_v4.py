import csv
import json
import math
from pathlib import Path

out = Path(__file__).resolve().parent
arms = {a: {r['model']: r for r in csv.DictReader((out / 'bench-v4' / (a + '.tsv')).open(), delimiter='\t')} for a in ('base', 'candidate')}
records = []
for name in sorted(set(arms['base']) | set(arms['candidate'])):
    rec = {'model': name}
    for arm in arms:
        row = arms[arm].get(name, {})
        rec[arm + '_note'] = row.get('note', 'missing row')
        for key in ('stanli_compile_s', 'stanli_prep_s', 'stanli_ns_grad', 'stanli_ns_grad_mad', 'stanli_estimated_s', 'cmdstan_ns_grad', 'cmdstan_ns_grad_mad', 'gradient_count'):
            rec[arm + '_' + key] = float(row[key]) if row.get(key) else None
    rec['complete'] = not rec['base_note'] and not rec['candidate_note']
    rec['major_regression'] = None
    if rec['complete']:
        for key in ('stanli_compile_s', 'stanli_prep_s', 'stanli_ns_grad', 'stanli_estimated_s', 'cmdstan_ns_grad'):
            b, c = (rec[a + '_' + key] for a in ('base', 'candidate'))
            rec[key + '_delta'] = c - b
            rec[key + '_ratio'] = c / b if b else None
        b, c = (rec[a + '_stanli_estimated_s'] for a in ('base', 'candidate'))
        rec['major_threshold_s'] = max(.02 * b, .005)
        rec['major_regression'] = c - b > rec['major_threshold_s']
    records.append(rec)
summary = {'protocol': 'original stanli-corpus-v6; six engine-paired rounds per arm, arms sequential',
           'threshold': 'candidate total minus baseline total > max(2% baseline total, 5 ms)',
           'counts': {'selected': len(records), 'complete_both': sum(r['complete'] for r in records), 'incomplete': sum(not r['complete'] for r in records), 'apparent_major_regressions': sum(r['major_regression'] is True for r in records)},
           'records': records}
(out / 'v4-comparison.json').write_text(json.dumps(summary, indent=2) + '\n')
keys = sorted(set().union(*(r.keys() for r in records)))
with (out / 'v4-comparison.tsv').open('w') as f:
    writer = csv.DictWriter(f, fieldnames=['model'] + [k for k in keys if k != 'model'], delimiter='\t')
    writer.writeheader(); writer.writerows(records)
print(json.dumps(summary['counts']))
for r in records:
    if not r['complete']:
        print(r['model'], 'INCOMPLETE', r['base_note'], '|', r['candidate_note']); continue
    print(r['model'], 'total%=' + format(100 * (r['stanli_estimated_s_ratio'] - 1), '.3f'),
          'warm%=' + format(100 * (r['stanli_ns_grad_ratio'] - 1), '.3f'),
          'prep_ms=' + format(r['base_stanli_prep_s'] * 1000, '.3f') + '->' + format(r['candidate_stanli_prep_s'] * 1000, '.3f'),
          'MAJOR' if r['major_regression'] else '')
