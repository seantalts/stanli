import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

own = Path(__file__).resolve().parents[2]
out = own / '.cache/covariance-storage-validation'
fix = own.parent / 'stanli-covariance-fix'
check = fix / 'build/stanli_check'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
env = os.environ.copy()
threads = {k: '1' for k in ['STAN_NUM_THREADS', 'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS']}
env.update(threads)
argv = [sys.executable, 'tools/verify_refs.py', '/Users/xitrium/claud/stanrt/deps/posteriordb', '--check', str(check), '--jobs', '2', '--timeout', '300', '--per-model']
meta = {'argv': argv, 'cwd': str(fix), 'check_sha256': sha(check), 'source_sha': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=fix, text=True).strip(),
        'tracked_diff_sha256': hashlib.sha256(subprocess.check_output(['git', 'diff', 'HEAD', '--binary'], cwd=fix)).hexdigest(), 'threads': threads,
        'native_source_sha256': {n: sha(fix / n) for n in ['runtime/src/structured_loop.cpp', 'runtime/src/structured_forward_only.inc', 'runtime/src/executor.cpp', 'runtime/include/stanli/kernel_types.hpp']}}
(out / 'v4-candidate-replay-command.json').write_text(json.dumps(meta, indent=2) + '\n')
start = time.time()
with (out / 'v4-candidate-replay.log').open('w') as f:
    r = subprocess.run(argv, cwd=fix, env=env, stdout=f, stderr=subprocess.STDOUT)
after = sha(check)
(out / 'v4-candidate-replay-process.json').write_text(json.dumps({'returncode': r.returncode, 'elapsed_s': time.time()-start, 'check_sha256_after': after}, indent=2) + '\n')
assert after == meta['check_sha256'], 'check binary changed during replay'
print('V3 numerical replay exit', r.returncode, 'seconds', time.time()-start, flush=True)
sys.exit(r.returncode)
