import json
import struct
import subprocess
import time
from pathlib import Path

out = Path(__file__).resolve().parent
diagnostic = json.loads((out / 'v2-ctsem-point-diagnostic.json').read_text())
q = json.loads((out / 'v2-ctsem-fixed-points.json').read_text())
events, results = [], {}
for label, indexes in {'fresh4': [4], 'prefix0to4': [0,1,2,3,4], 'repeat4_0_4': [4,0,4]}.items():
    points = out / ('v2-ctsem-sequence-' + label + '.json')
    points.write_text(json.dumps([q[i] for i in indexes]) + '\n')
    results[label] = {}
    for arm, engine in [('base', 'stanli'), ('candidate', 'stanli'), ('base', 'cmdstan')]:
        original = next(e for e in diagnostic['commands'][arm] if e['phase'].endswith('/' + engine))
        argv = original['argv'][:original['argv'].index('--timed')] + ['--timed', '--warmup-ms', '1', '--measure-ms', '1', '--points-file', str(points)]
        start = time.time()
        p = subprocess.run(argv, cwd=original['cwd'], capture_output=True, text=True, timeout=60)
        event = {'label': label, 'indexes': indexes, 'arm': arm, 'engine': engine, 'argv': argv, 'cwd': original['cwd'], 'started_unix_s': start,
                 'elapsed_s': time.time()-start, 'returncode': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}
        events.append(event)
        if p.returncode: raise RuntimeError(event)
        results[label][arm + '_' + engine] = json.loads(p.stdout.splitlines()[-1])
    print(label, 'finished', flush=True)
bits = lambda xs: [struct.pack('>d', x).hex() for x in xs]
summaries = []
for label, arms in results.items():
    for arm_engine, result in arms.items():
        original_arm, engine = arm_engine.split('_', 1)
        for i, point in enumerate(result['points']):
            k = next(e['indexes'] for e in events if e['label'] == label)[i]
            prior = diagnostic['raw'][original_arm][engine]['points'][k]
            summaries.append({'label': label, 'arm_engine': arm_engine, 'position': i, 'original_point': k,
                              'bitwise_identical_to_original_10point_sequence': point['finite'] == prior['finite'] and bits(point.get('values', [])) == bits(prior.get('values', []))})
report = {'purpose': 'fresh q4 versus sequence0..4 versus q4,0,q4; numerical diagnostic only, 1ms timing excluded from performance evidence',
          'all_values_bitwise_unchanged_by_order': all(s['bitwise_identical_to_original_10point_sequence'] for s in summaries),
          'summaries': summaries, 'events': events}
(out / 'v2-ctsem-sequence-discriminator.json').write_text(json.dumps(report, indent=2) + '\n')
print('all values bitwise unchanged by order:', report['all_values_bitwise_unchanged_by_order'])
