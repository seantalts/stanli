import hashlib
import json
import statistics
import subprocess
import time
from pathlib import Path

out = Path(__file__).resolve().parent
own = out.parents[1]
selection = json.loads((out / 'selection-v2/selection.json').read_text())
names = sorted(set(selection['prep_regressed']) | {'mlumr_survival_mspline_relaxed', 'one_comp_mm_elim_abs', 'eight_schools_noncentered'})
sources = {'base': own.parent / 'stanli-covariance-base', 'candidate': own.parent / 'stanli-covariance-fix'}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
identity = {a: {'source': str(p), 'bench_sha256': sha(p / 'build/bench_grad')} for a, p in sources.items()}
events = []
for name in names:
    for rep in range(6):
        for arm in (('base', 'candidate') if rep % 2 == 0 else ('candidate', 'base')):
            mir = out / 'selection-v2' / arm / name / 'model.sexp'
            data = out / 'selection-v2/inputs' / (name + '.json')
            argv = [str(sources[arm] / 'build/bench_grad'), str(mir), str(data), '--prep']
            start = time.time()
            r = subprocess.run(argv, cwd=sources[arm], capture_output=True, text=True, timeout=300)
            event = {'model': name, 'round': rep, 'arm': arm, 'argv': argv, 'cwd': str(sources[arm]), 'started_unix_s': start, 'process_elapsed_s': time.time() - start,
                     'returncode': r.returncode, 'stdout': r.stdout, 'stderr': r.stderr, 'mir_sha256': sha(mir), 'data_sha256': sha(data)}
            if r.returncode == 0:
                event['preparation_s'] = float(r.stdout.splitlines()[-1].split()[0])
            events.append(event)
            (out / 'v2-preparation-followup-events.json').write_text(json.dumps({'identity': identity, 'events': events}, indent=2) + '\n')
    print(name, 'finished', flush=True)
summary = {'purpose': 'explain all four all-corpus preparation flags, retained V1 flag and two small controls; original selection unchanged',
           'rounds': 6, 'order': 'base/candidate on even rounds, candidate/base on odd rounds', 'models': {}}
for name in names:
    pairs = [{a: next(e['preparation_s'] for e in events if e['model'] == name and e['round'] == i and e['arm'] == a) for a in sources} for i in range(6)]
    medians = {a: statistics.median(p[a] for p in pairs) for a in sources}
    deltas = [p['candidate'] - p['base'] for p in pairs]
    ratios = [p['candidate'] / p['base'] for p in pairs]
    summary['models'][name] = {'median_s': medians, 'paired_deltas_s': deltas, 'paired_ratios': ratios,
                             'median_paired_delta_s': statistics.median(deltas), 'median_paired_ratio': statistics.median(ratios),
                             'paired_delta_mad_s': statistics.median(abs(d - statistics.median(deltas)) for d in deltas)}
    print(name, json.dumps(summary['models'][name]), flush=True)
assert identity == {a: {'source': str(p), 'bench_sha256': sha(p / 'build/bench_grad')} for a, p in sources.items()}
(out / 'v2-preparation-followup-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
