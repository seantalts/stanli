import hashlib
import json
import struct
from pathlib import Path

out = Path(__file__).resolve().parent
model = 'ctsem_ctsm_post4_100'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
bits = lambda x: struct.pack('>d', x).hex()
def ordered(x):
    i = struct.unpack('>q', struct.pack('>d', x))[0]
    return 0x8000000000000000 - i if i < 0 else i

mask = (1 << 64) - 1
def splitmix(x):
    x = (x + 0x9E3779B97F4A7C15) & mask
    x = ((x ^ (x >> 30)) * 0xBF58476D1CE4E5B9) & mask
    x = ((x ^ (x >> 27)) * 0x94D049BB133111EB) & mask
    return x ^ (x >> 31)

def point(k, n):
    if k == 0:
        return [0.1 + 0.05 * (i % 7) - 0.15 * (i % 3) for i in range(n)]
    return [-2.0 + 4.0 * float(splitmix(splitmix((k * 0x9E3779B97F4A7C15) & mask) ^ i) >> 11) * 2.0**-53 for i in range(n)]

raw, commands, pins = {}, {}, {}
for arm in ('base', 'candidate'):
    run = out / 'bench-v2' / (arm + '.tsv.run')
    events = [json.loads(s) for s in (run / 'events.jsonl').read_text().splitlines()]
    chosen = [e for e in events if e['phase'].startswith(model + '/gradient/0/')]
    commands[arm] = chosen
    raw[arm] = {e['phase'].rsplit('/', 1)[-1]: json.loads((run / e['stdout']).read_text().splitlines()[-1]) for e in chosen}
    manifest = json.loads((run / 'manifest.json').read_text())
    pins[arm] = {k: manifest['identity'][k] for k in ('toolchains', 'executables', 'sources')}

summaries = []
all_exact = True
for k in range(10):
    b = raw['base']['stanli']['points'][k]
    c = raw['candidate']['stanli']['points'][k]
    r = raw['base']['cmdstan']['points'][k]
    s = raw['candidate']['cmdstan']['points'][k]
    exact = b['finite'] == c['finite'] and [bits(x) for x in b.get('values', [])] == [bits(x) for x in c.get('values', [])]
    ref_exact = r['finite'] == s['finite'] and [bits(x) for x in r.get('values', [])] == [bits(x) for x in s.get('values', [])]
    all_exact &= exact and ref_exact
    errors = [abs(x-y)/max(abs(x),abs(y),1) for x,y in zip(b.get('values', []), r.get('values', []))]
    i = max(range(len(errors)), key=errors.__getitem__)
    x, y = b['values'][i], r['values'][i]
    summaries.append({'point': k, 'base_candidate_stanli_bitwise_identical': exact, 'base_candidate_cmdstan_bitwise_identical': ref_exact,
                      'worst_scaled_component': i, 'unconstrained_gradient_index_zero_based': i - 1, 'stanli': x, 'cmdstan': y,
                      'absolute_error': abs(x-y), 'scaled_error': errors[i], 'ulp_error': abs(ordered(x)-ordered(y)),
                      'density_stanli': b['values'][0], 'density_cmdstan': r['values'][0]})
n = len(raw['base']['stanli']['points'][0]['values']) - 1
q = [point(k, n) for k in range(10)]
(out / 'v2-ctsem-fixed-points.json').write_text(json.dumps(q) + '\n')
(out / 'v2-ctsem-point4.json').write_text(json.dumps([q[4]]) + '\n')
result = {'model': model, 'n_params': n, 'summary': summaries, 'all_10_points_both_engines_bitwise_identical_between_arms': all_exact,
          'point_generator': 'tools/benchmark_timer.hpp evaluation_point; integer uint64 SplitMix64, q=-2+4*u (point0 special formula)',
          'points_file': str(out / 'v2-ctsem-fixed-points.json'), 'points_sha256': sha(out / 'v2-ctsem-fixed-points.json'),
          'first_failing_point': 4, 'failing_unconstrained_index_zero_based': 449, 'failing_named_parameter': 'tipredeffectparams[55]',
          'parameter_mapping': '185 rawpopmeans +20 rawpopsdbase +190 sqrtpcov; 0 baseindparams when intoverpop=1; remaining185 tipredeffectparams',
          'known_baseline_record': 'docs/benchmarks.md:418,574; output/corpus-performance/README.md:390, run c08b96efbdcf4d78 (2026-11-19)',
          'gate_result': 'UNRESOLVED baseline numerical discrepancy; no tolerance/points change and no claim this selected model passed',
          'commands': commands, 'provenance': pins, 'raw': raw}
(out / 'v2-ctsem-point-diagnostic.json').write_text(json.dumps(result, indent=2) + '\n')
print('all10 both engines BASE/FIX bitwise identical:', all_exact)
print(json.dumps(summaries[4], indent=1))
print('q[449]:', repr(q[4][449]))
