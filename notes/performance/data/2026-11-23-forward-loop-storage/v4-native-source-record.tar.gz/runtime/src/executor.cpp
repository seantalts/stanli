#include <stanli/debug_switch.hpp>
#include <stanli/graph.hpp>
#include <stanli/optable.hpp>
#include <stanli/program.hpp>
#include <stanli/packet.hpp>

#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <map>
#include <stdexcept>
#include <string>
#include <utility>

namespace stanli {

namespace {
constexpr size_t kMinMicroRun = 2;
}  // namespace

using ForwardFn = void (*)(KernelCtx&);
ForwardFn resolve_forward_fn(const Op& op);

static Kernel g_table[OP_COUNT_];

Kernel& kernel(uint16_t opcode) {
  assert(opcode < OP_COUNT_);
  return g_table[opcode];
}

// Atomic so that a test flipping it cannot race a kernel on another thread.
static std::atomic<bool> g_fixed_small_matrices{true};
bool fixed_small_matrices() {
  return g_fixed_small_matrices.load(std::memory_order_relaxed);
}
void set_fixed_small_matrices(bool on) {
  g_fixed_small_matrices.store(on, std::memory_order_relaxed);
}

const char* opcode_name(uint16_t opcode) {
  static const char* const names[] = {
      "OP_NONE_",
#define STANLI_OPCODE_NAME(name) #name,
#define STANLI_DENSITY_OPCODE_NAME(code, fn, ...) #code,
#define STANLI_UNARY_OPCODE_NAME(code, fn, value, delta, topology) #code,
      STANLI_ALL_OPCODES(STANLI_OPCODE_NAME, STANLI_DENSITY_OPCODE_NAME,
                         STANLI_UNARY_OPCODE_NAME)
#undef STANLI_OPCODE_NAME
#undef STANLI_DENSITY_OPCODE_NAME
#undef STANLI_UNARY_OPCODE_NAME
  };
  return opcode < OP_COUNT_ ? names[opcode] : "OP_?";
}

void register_kernel(uint16_t opcode, Kernel k) {
  if (opcode >= OP_COUNT_)
    throw std::logic_error("register_kernel: opcode out of range");
  if (g_table[opcode].forward != nullptr)
    throw std::logic_error(std::string("register_kernel: ") +
                           opcode_name(opcode) + " is already registered");
  g_table[opcode] = k;
}

static void ensure_registered();

const Kernel* find_kernel(uint16_t opcode) {
  ensure_registered();
  if (opcode >= OP_COUNT_) return nullptr;
  const Kernel& k = g_table[opcode];
  return k.forward ? &k : nullptr;
}

// CALL support (program.hpp): the register machine invoking a graph kernel.
// Only pointer fields vary with a register-file base. Dispatch and the
// integer/shape metadata are immutable call-site facts, so builders resolve
// the former once and a program invocation reuses one context packet across
// all of its CALL instructions.
void bind_call_fwd_ctx(const Program::Call& call, double* reg, KernelCtx& ctx,
                       EvalState* state) {
  ctx.n_in = call.n_in;
  for (int k = 0; k < call.n_in; ++k)
    ctx.in[k] = Desc{reg + call.in[k], call.in_len[k]};
  ctx.out = Desc{reg + call.out, call.out_len};
  ctx.variant = call.variant;
  ctx.scratch = reg + call.scratch;
  ctx.idata = call.idata.data();
  ctx.n_idata = (int64_t)call.idata.size();
  ctx.udata = call.udata_owner.get();
  // Not a call-site fact: the draw stream belongs to the evaluation, so it
  // is rebound with the pointer fields rather than resolved once.
  ctx.eval_state = state;
}

bool bind_call(Program::Call& call) {
  call.forward = nullptr;
  call.backward = nullptr;
  const Kernel* k = find_kernel(call.opcode);
  if (k == nullptr || k->forward == nullptr) return false;
  call.forward = k->forward;
  call.backward = k->backward;
  return true;
}

int64_t kernel_call_scratch(int64_t (*scratch_size)(const Op&, const Slot*),
                            uint16_t opcode, uint8_t variant, int8_t n_in,
                            const int32_t* in_len, int32_t out_len,
                            const int* idata, int64_t n_idata,
                            const void* udata) {
  if (scratch_size == nullptr) return 0;
  Op op;
  op.opcode = opcode;
  op.variant = variant;
  op.n_in = n_in;
  op.out = n_in;
  op.idata = idata;
  op.n_idata = n_idata;
  op.udata = udata;
  std::vector<Slot> slots((size_t)n_in + 1);
  for (int k = 0; k < n_in; ++k) {
    op.in[k] = k;
    slots[(size_t)k].len = in_len[k];
  }
  slots.back().len = out_len;
  return scratch_size(op, slots.data());
}

void run_call_var(const Program::Call& call, stan::math::var* reg) {
  using ArenaDoubles = stan::arena_t<std::vector<double>>;
  using ArenaVaris = stan::arena_t<std::vector<stan::math::vari*>>;
  if (call.forward == nullptr || call.backward == nullptr)
    throw std::logic_error("unbound Program::CALL var replay");

  std::array<int32_t, 6> in_offset{};
  int32_t total = 0;
  for (int k = 0; k < call.n_in; ++k) {
    in_offset[(size_t)k] = total;
    total += call.in_len[k];
  }
  const int32_t out_offset = total;
  total += call.out_len;
  const int32_t scratch_offset = total;
  total += call.scratch_len;

  ArenaDoubles values((size_t)total, 0.0);
  ArenaVaris input_varis;
  const bool active = call.input_adjoint_mask != 0;
  if (active) input_varis.reserve((size_t)out_offset);
  for (int k = 0; k < call.n_in; ++k) {
    for (int i = 0; i < call.in_len[k]; ++i) {
      const stan::math::var& x = reg[(size_t)(call.in[k] + i)];
      values[(size_t)(in_offset[(size_t)k] + i)] = x.val();
      if (active) input_varis.push_back(x.vi_);
    }
  }

  KernelCtx ctx;
  double* const value_base = values.empty() ? nullptr : values.data();
  ctx.n_in = call.n_in;
  for (int k = 0; k < call.n_in; ++k)
    ctx.in[k] = Desc{value_base ? value_base + in_offset[(size_t)k] : nullptr,
                     call.in_len[k]};
  ctx.out = Desc{value_base ? value_base + out_offset : nullptr, call.out_len};
  ctx.variant = call.variant;
  ctx.scratch = value_base ? value_base + scratch_offset : nullptr;
  ctx.idata = call.idata.data();
  ctx.n_idata = (int64_t)call.idata.size();
  ctx.udata = call.udata_owner.get();
  call.forward(ctx);

  ArenaVaris output_varis(active ? (size_t)call.out_len : 0);
  for (int i = 0; i < call.out_len; ++i) {
    reg[(size_t)(call.out + i)] =
        stan::math::var(values[(size_t)(out_offset + i)]);
    if (active) output_varis[(size_t)i] = reg[(size_t)(call.out + i)].vi_;
  }
  // Inactive calls still perform their forward computation and validation.
  // Their fresh constant outputs have no reverse edges to retain.
  if (!active) return;

  ArenaDoubles adjoints((size_t)total, 0.0);
  const KernelFn backward = call.backward;
  const uint8_t variant = call.variant;
  const uint8_t input_adjoint_mask = call.input_adjoint_mask;
  const int8_t n_in = call.n_in;
  std::array<int32_t, 6> in_len{};
  for (int k = 0; k < n_in; ++k) in_len[(size_t)k] = call.in_len[k];
  const int32_t out_len = call.out_len;
  const stan::arena_t<std::vector<int>> idata(call.idata.begin(),
                                              call.idata.end());
  const void* const udata = call.udata_owner.get();
  stan::math::reverse_pass_callback([backward, variant, input_adjoint_mask,
                                     n_in, in_len, out_len, idata, udata,
                                     values, adjoints, input_varis,
                                     output_varis, in_offset, out_offset,
                                     scratch_offset]() mutable {
    std::fill(adjoints.begin(), adjoints.end(), 0.0);
    KernelCtx reverse;
    double* const value_base = values.empty() ? nullptr : values.data();
    double* const adjoint_base = adjoints.empty() ? nullptr : adjoints.data();
    reverse.n_in = n_in;
    for (int k = 0; k < n_in; ++k) {
      reverse.in[k] =
          Desc{value_base ? value_base + in_offset[(size_t)k] : nullptr,
               in_len[(size_t)k]};
      reverse.in_adj[k] =
          (input_adjoint_mask & (uint8_t)(1u << k))
              ? Desc{adjoint_base ? adjoint_base + in_offset[(size_t)k]
                                  : nullptr,
                     in_len[(size_t)k]}
              : Desc{nullptr, in_len[(size_t)k]};
    }
    reverse.out = Desc{value_base ? value_base + out_offset : nullptr, out_len};
    reverse.variant = variant;
    reverse.scratch = value_base ? value_base + scratch_offset : nullptr;
    reverse.idata = idata.data();
    reverse.n_idata = (int64_t)idata.size();
    reverse.udata = udata;
    for (int i = 0; i < out_len; ++i)
      adjoints[(size_t)(out_offset + i)] = output_varis[(size_t)i]->adj_;
    reverse.out_adj_vec =
        Desc{adjoint_base ? adjoint_base + out_offset : nullptr, out_len};
    reverse.out_adj = out_len == 1 ? output_varis[0]->adj_ : 0.0;
    backward(reverse);

    size_t vari_at = input_varis.size();
    for (int k = n_in; k-- > 0;) {
      vari_at -= (size_t)in_len[(size_t)k];
      if (!(input_adjoint_mask & (uint8_t)(1u << k))) continue;
      for (int i = in_len[(size_t)k]; i-- > 0;)
        input_varis[vari_at + (size_t)i]->adj_ +=
            adjoints[(size_t)(in_offset[(size_t)k] + i)];
    }
  });
}

void run_call(const Program::Call& call, double* reg, KernelCtx& ctx,
              EvalState* state) {
  if (call.forward == nullptr)
    throw std::logic_error("unbound Program::CALL forward");
  bind_call_fwd_ctx(call, reg, ctx, state);
  call.forward(ctx);
}

void run_call(const Program::Call& call, double* reg, EvalState* state) {
  KernelCtx ctx;
  run_call(call, reg, ctx, state);
}

void register_elementwise_kernels();
void register_density_kernels();
void register_probability_fns_kernels();
void register_legacy_kernels();
void register_matrix_kernels();
void register_library_kernels();
void register_algebra_kernels();
void register_quadrature_kernels();
void register_ode_kernels();
void register_dae_kernels();
void register_ode_adjoint_kernels();
void register_constrain_kernels();
void register_eltwise_kernels();
void register_scalar_binary_kernels();
void register_scalar_unary_ad_kernels();
void register_mixture_kernels();
void register_message_kernels();
void register_rng_kernel();
void register_island_kernel();
void register_region_map_kernel();
void register_structured_loop_kernel();
void register_reduce_sum_kernel();
void register_whiten_kernel();

static void register_all_kernels() {
  register_elementwise_kernels();
  register_density_kernels();
  register_probability_fns_kernels();
  register_legacy_kernels();
  register_matrix_kernels();
  register_library_kernels();
  register_algebra_kernels();
  register_quadrature_kernels();
  register_ode_kernels();
  register_dae_kernels();
  register_ode_adjoint_kernels();
  register_constrain_kernels();
  register_message_kernels();
  register_rng_kernel();
  register_eltwise_kernels();
  register_scalar_binary_kernels();
  register_scalar_unary_ad_kernels();
  register_mixture_kernels();
  register_island_kernel();
  register_region_map_kernel();
  register_structured_loop_kernel();
  register_reduce_sum_kernel();
  register_whiten_kernel();
}

// A built-in opcode registered twice is a build defect. The registration
// runs once, and every later call throws the same error: a second attempt
// would start from a half-filled table and report the wrong opcode. The
// runtime may not write to stderr or abort (tools/check_no_stdio.sh).
static void ensure_registered() {
  static const std::string error = []() -> std::string {
    try {
      register_all_kernels();
    } catch (const std::exception& e) {
      return e.what();
    }
    return {};
  }();
  if (!error.empty()) throw std::logic_error(error);
}

void Graph::compact_idata() {
  if (compact_idata_ || idata_pool.empty()) return;

  bool has_views = false;
  for (const Op& op : ops) {
    if (op.n_idata < 0 || (op.n_idata > 0 && op.idata == nullptr)) return;
    has_views |= op.idata != nullptr;
  }
  if (!has_views) {
    // Rewrites can remove every integer-using op but leave its pool behind.
    // No lookup or temporary allocation is needed to release an all-dead pool.
    std::vector<std::vector<int>>{}.swap(idata_pool);
    return;
  }

  // Exact bases are the mutable pool's ownership contract. In particular,
  // do not infer ownership using pointer ranges: const-folding subgraphs
  // borrow parent payloads, and hand-built graphs can borrow external data.
  constexpr size_t unused = std::numeric_limits<size_t>::max();
  struct Entry {
    const int* data;
    size_t pool_index;
    size_t offset = unused;
  };
  std::vector<Entry> entries;
  entries.reserve(idata_pool.size());
  for (size_t i = 0; i < idata_pool.size(); ++i)
    if (!idata_pool[i].empty()) entries.push_back({idata_pool[i].data(), i});
  std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {
    return std::less<const int*>{}(a.data, b.data);
  });
  const auto find = [&](const int* p) {
    return std::lower_bound(entries.begin(), entries.end(), p,
                            [](const Entry& entry, const int* value) {
                              return std::less<const int*>{}(entry.data, value);
                            });
  };

  size_t total = 0;
  const size_t max_size = std::vector<int>{}.max_size();
  for (const Op& op : ops) {
    if (op.idata == nullptr) continue;
    const auto entry = find(op.idata);
    if (entry == entries.end() || entry->data != op.idata) return;
    const size_t size = idata_pool[entry->pool_index].size();
    if (static_cast<uint64_t>(op.n_idata) > size) return;
    if (entry->offset == unused) {
      if (size > max_size - total)
        throw std::length_error("integer payload storage is too large");
      entry->offset = total;
      total += size;
    }
  }

  std::shared_ptr<std::vector<int>> compact;
  if (total != 0) {
    compact = std::make_shared<std::vector<int>>(total);
    for (const Entry& entry : entries) {
      if (entry.offset == unused) continue;
      const auto& payload = idata_pool[entry.pool_index];
      std::copy(payload.begin(), payload.end(), compact->data() + entry.offset);
    }
  }

  // Every allocation and refusal precedes publication. The remaining raw
  // pointer assignments, shared_ptr move and vector swap cannot throw.
  compact_idata_ = std::move(compact);
  for (Op& op : ops) {
    if (op.idata == nullptr) continue;
    const auto entry = find(op.idata);
    assert(entry != entries.end() && entry->offset != unused);
    op.idata = compact_idata_->data() + entry->offset;
  }
  // clear() would retain the outer vector's per-payload metadata capacity.
  std::vector<std::vector<int>>{}.swap(idata_pool);
}

Executor::Executor(Graph g) : graph_(std::move(g)) {
  ensure_registered();
  graph_.compact_idata();
  bind_();
}

Executor::Executor(Graph g, std::vector<Borrow> borrows)
    : graph_(std::move(g)) {
  ensure_registered();
  graph_.compact_idata();
  borrowed_.assign(graph_.slots.size(), nullptr);
  for (const auto& borrow : borrows) {
    if (borrow.slot < 0 || size_t(borrow.slot) >= graph_.slots.size() ||
        !borrow.data)
      throw std::invalid_argument("borrowed slot is not in the graph");
    borrowed_[size_t(borrow.slot)] = borrow.data;
  }
  bind_();
}

Executor::Executor(Graph g, const Executor& source)
    : graph_(std::move(g)),
      data_(source.data_pointer_exposed_
                ? std::make_shared<std::vector<double>>(*source.data_)
                : source.data_),
      borrowed_(source.borrowed_) {
  ensure_registered();
  graph_.compact_idata();
  if (!borrowed_.empty()) borrowed_.resize(graph_.slots.size(), nullptr);
  bind_();
}

Executor::Executor(const Executor& src)
    : graph_(src.graph_),
      data_(src.data_pointer_exposed_
                ? std::make_shared<std::vector<double>>(*src.data_)
                : src.data_),
      borrowed_(src.borrowed_) {
  ensure_registered();
  bind_();
  std::copy(src.values_.begin(), src.values_.end(), values_.begin());
  for (size_t i = 0; i < ctx_.size(); ++i)
    if (ctx_[i].state && src.ctx_[i].state)
      ctx_[i].state->clone_from(*src.ctx_[i].state);
}

// Doubles per 64 bytes, the widest vector alignment a kernel may reach.
constexpr int64_t kScratchAlignment = 8;

// A forward-only graph runs its ops once each, in order, so a written slot
// needs storage only from the op that first writes it to the last op that
// reads or writes it. Afterwards its storage goes to a later slot of the
// same length that would have started at the same offset modulo 64 bytes,
// so every kernel sees the alignment it had before. Parameters, pinned slots
// and the slots that cached primals share keep their own storage. Returns
// the new size of the value arena.
int64_t Executor::reuse_values_(const std::vector<char>& written,
                                const std::vector<int>& primal_sources,
                                int64_t end) {
  const size_t n = graph_.slots.size();
  std::vector<char> fixed(n, 0);
  for (size_t i = 0; i < n; ++i) {
    const Slot& s = graph_.slots[i];
    fixed[i] = !written[i] || s.is_param || s.pinned || s.len == 0 ||
               (!borrowed_.empty() && borrowed_[i]) ||
               (int)i == graph_.result_slot;
  }
  for (size_t i = 0; i < primal_sources.size(); ++i)
    if (primal_sources[i] >= 0) fixed[i] = fixed[(size_t)primal_sources[i]] = 1;
  std::vector<int64_t> last(n, -1);
  std::vector<char> placed(n, 0);
  const auto runs = [](const Op& op) {
    return op.primal_source < 0 || op.primal_source == op.out;
  };
  for (size_t k = 0; k < graph_.ops.size(); ++k) {
    const Op& op = graph_.ops[k];
    if (!runs(op)) continue;
    for (int j = 0; j < op.n_in; ++j) last[(size_t)op.in[j]] = (int64_t)k;
    last[(size_t)op.out] = (int64_t)k;
    if (op.out2 >= 0) last[(size_t)op.out2] = (int64_t)k;
  }
  int64_t top = n_params_;
  const auto place_new = [&](Slot& s) {
    const int64_t residue = s.offset % kScratchAlignment;
    top += ((residue - top % kScratchAlignment) + kScratchAlignment) %
           kScratchAlignment;
    s.offset = top;
    top += s.len;
  };
  // Fixed slots keep a region of their own, laid out first.
  for (size_t i = 0; i < n; ++i)
    if (written[i] && !graph_.slots[i].is_param && fixed[i] &&
        (primal_sources.empty() || primal_sources[i] < 0) &&
        (borrowed_.empty() || !borrowed_[i])) {
      place_new(graph_.slots[i]);
      placed[i] = 1;
    }
  std::map<std::pair<int64_t, int64_t>, std::vector<int64_t>> free_blocks;
  const auto place = [&](int slot) {
    if (slot < 0 || placed[(size_t)slot] || fixed[(size_t)slot]) return;
    Slot& s = graph_.slots[(size_t)slot];
    placed[(size_t)slot] = 1;
    auto found = free_blocks.find({s.len, s.offset % kScratchAlignment});
    if (found != free_blocks.end() && !found->second.empty()) {
      s.offset = found->second.back();
      found->second.pop_back();
      return;
    }
    place_new(s);
  };
  const auto release = [&](int slot, int64_t k) {
    if (slot < 0 || fixed[(size_t)slot] || last[(size_t)slot] != k) return;
    const Slot& s = graph_.slots[(size_t)slot];
    last[(size_t)slot] = -2;  // released once
    free_blocks[{s.len, s.offset % kScratchAlignment}].push_back(s.offset);
  };
  for (size_t k = 0; k < graph_.ops.size(); ++k) {
    const Op& op = graph_.ops[k];
    if (!runs(op)) continue;
    place(op.out);
    place(op.out2);
    for (int j = 0; j < op.n_in; ++j) release(op.in[j], (int64_t)k);
    release(op.out, (int64_t)k);
    release(op.out2, (int64_t)k);
  }
  // A written slot that no running op touches keeps a region of its own.
  for (size_t i = 0; i < n; ++i)
    if (written[i] && !placed[i] && !fixed[i]) place_new(graph_.slots[i]);
  (void)end;
  return top;
}

void Executor::bind_() {
  const auto checked_size = [](int64_t a, int64_t b) {
    const auto max = static_cast<uint64_t>(std::vector<double>{}.max_size());
    if (a < 0 || b < 0 || static_cast<uint64_t>(a) > max ||
        static_cast<uint64_t>(b) > max - static_cast<uint64_t>(a))
      throw std::length_error("executor arena size overflow");
    return a + b;
  };
  if (graph_.result_slot < -1 ||
      graph_.result_slot >= static_cast<int>(graph_.slots.size()))
    throw std::invalid_argument("result slot is not in the graph");
  // Only parameters and written slots need private value storage. Classify
  // both outputs, including inactive writes: activity is not immutability.
  std::vector<char> written(graph_.slots.size(), 0);
  bool has_shared_primals = false;
  size_t n_forward = 0;
  for (const auto& op : graph_.ops) {
    written[op.out] = 1;
    if (op.out2 >= 0) written[op.out2] = 1;
    has_shared_primals |= op.primal_source >= 0;
    n_forward += op.primal_source < 0 || op.primal_source == op.out;
  }
  std::vector<int> primal_sources;
  if (has_shared_primals) {
    primal_sources.assign(graph_.slots.size(), -1);
    for (const auto& op : graph_.ops)
      if (op.primal_source >= 0 && op.primal_source != op.out)
        primal_sources[(size_t)op.out] = op.primal_source;
  }
  int64_t off = 0, data_size = 0;
  data_offsets_.assign(graph_.slots.size(), -1);
  for (auto& s : graph_.slots) {
    if (s.is_param) {
      s.offset = off;
      off = checked_size(off, s.len);
    }
  }
  n_params_ = off;
  for (size_t i = 0; i < graph_.slots.size(); ++i) {
    auto& s = graph_.slots[i];
    const bool borrowed = !borrowed_.empty() && borrowed_[i];
    if (borrowed && (s.is_param || written[i]))
      throw std::invalid_argument("only unwritten data can be borrowed");
    if (s.is_param) continue;
    if (borrowed) {
      s.offset = 0;
    } else if (written[i]) {
      if (has_shared_primals && primal_sources[i] >= 0) continue;
      s.offset = off;
      off = checked_size(off, s.len);
    } else {
      s.offset = data_size;
      data_offsets_[i] = data_size;
      data_size = checked_size(data_size, s.len);
    }
  }
  if (graph_.forward_only) off = reuse_values_(written, primal_sources, off);
  if (has_shared_primals)
    for (size_t i = 0; i < graph_.slots.size(); ++i)
      if (primal_sources[i] >= 0)
        graph_.slots[i].offset = graph_.slots[(size_t)primal_sources[i]].offset;
  values_.assign(off, 0.0);
  if (!data_) data_ = std::make_shared<std::vector<double>>(data_size, 0.0);
  if (static_cast<int64_t>(data_->size()) != data_size)
    throw std::invalid_argument("shared data does not match the graph");

  // Adjoint addresses never escape the executor, so unlike values they do
  // not need a hole for every externally addressable data slot or for slots
  // whose producer an optimization pass removed. Pack the active cells into
  // one arena. Keeping parameters first preserves the contiguous memcpy of
  // the returned gradient; keeping one arena preserves the single fast
  // memset on dense graphs.
  std::vector<int64_t> adjoint_offsets(graph_.slots.size(), -1);
  int64_t adj_off = 0;
  for (size_t i = 0; i < graph_.slots.size() && !graph_.forward_only; ++i) {
    const Slot& s = graph_.slots[i];
    if (s.is_param) {
      adjoint_offsets[i] = adj_off;
      adj_off = checked_size(adj_off, s.len);
    }
  }
  assert(graph_.forward_only || adj_off == n_params_);
  for (size_t i = 0; i < graph_.slots.size() && !graph_.forward_only; ++i) {
    const Slot& s = graph_.slots[i];
    if (!s.is_param && (written[i] || (int)i == graph_.result_slot)) {
      adjoint_offsets[i] = adj_off;
      adj_off = checked_size(adj_off, s.len);
    }
  }
  adjoints_.assign(adj_off, 0.0);
  result_adjoint_offset_ = -1;
  if (graph_.result_slot >= 0 && !graph_.forward_only) {
    result_adjoint_offset_ = adjoint_offsets[graph_.result_slot];
    assert(result_adjoint_offset_ >= 0);
  }

  int64_t scratch = 0, unshared = 0;
  // Scratch layout is binding state, not graph structure. Only the bound
  // context pointers survive this function; copies compute their own layout.
  std::vector<int64_t> scratch_offsets;
  scratch_offsets.reserve(graph_.ops.size());
  // Reuse the optional map now that value offsets have been assigned.
  if (has_shared_primals)
    std::fill(primal_sources.begin(), primal_sources.end(), -1);
  for (const auto& op : graph_.ops) {
    const Kernel& k = kernel(op.opcode);
    if (op.opcode == OP_NONE_ || k.forward == nullptr)
      // Name it. A browser build can be missing a kernel because its
      // density pack has not been loaded yet, and the caller decides what
      // to do from this string.
      throw std::runtime_error(std::string("opcode not registered: ") +
                               opcode_name(op.opcode));
    if (op.primal_source >= 0 && op.primal_source != op.out) {
      const int source = primal_sources[(size_t)op.primal_source];
      if (source < 0)
        throw std::logic_error("cached primal precedes its source");
      scratch_offsets.push_back(scratch_offsets[(size_t)source]);
      continue;
    }
    if (op.primal_source == op.out)
      primal_sources[(size_t)op.out] = (int)scratch_offsets.size();
    const int64_t need =
        k.scratch_size ? k.scratch_size(op, graph_.slots.data()) : 0;
    // An op's scratch outlives the op only for its own backward, or for a
    // cached primal that reads it there. Without a backward, every op can
    // use the same region. Each op keeps the alignment it would have had in
    // its own region, because a vectorized reduction over scratch rounds
    // differently at a different alignment.
    if (graph_.forward_only) {
      const int64_t offset = unshared % kScratchAlignment;
      scratch_offsets.push_back(offset);
      scratch = std::max(scratch, checked_size(offset, need));
      unshared = checked_size(unshared, need);
      continue;
    }
    scratch_offsets.push_back(scratch);
    scratch = checked_size(scratch, need);
  }
  scratch_.assign(scratch, 0.0);

  // Assemble every kernel context once, now that all three arenas are sized
  // and every offset is final. Reassembling one per op per sweep cost a
  // scattered slot lookup per input and ~300 bytes of stores, twice per
  // gradient, which on the serial models (one op per observation, nothing to
  // vectorize) was a third of the time.
  ctx_.resize(graph_.ops.size());
  kernel_states_.clear();
  // Keep executable forwards in a contiguous prefix. Cached primals only
  // need their original reverse callbacks, so their contexts follow it.
  // The ordinary forward loop and its context layout stay unchanged.
  if (has_shared_primals) primal_sources.resize(graph_.ops.size());
  size_t next_forward = 0, next_cached = n_forward;
  for (size_t i = 0; i < graph_.ops.size(); ++i) {
    const Op& op = graph_.ops[i];
    const size_t ci = op.primal_source >= 0 && op.primal_source != op.out
                          ? next_cached++
                          : next_forward++;
    if (has_shared_primals) primal_sources[i] = static_cast<int>(ci);
    ctx_[ci] = make_ctx_(op, scratch_offsets[i], written, adjoint_offsets);
    const Kernel& k = kernel(graph_.ops[i].opcode);
    if (k.make_state) {
      std::unique_ptr<KernelState> state(
          k.make_state(graph_.ops[i], graph_.slots.data()));
      if (state) {
        ctx_[ci].state = state.get();
        kernel_states_.push_back(std::move(state));
      }
    }
  }
  // Resolve dispatch now that ctx_ is final (it never reallocates after
  // this, so BwdStep may hold pointers into it).
  fwd_fn_.clear();
  fwd_fn_.reserve(n_forward);
  bwd_.clear();
  bwd_.reserve(graph_.ops.size());
  for (size_t i = 0; i < graph_.ops.size(); ++i) {
    const Op& op = graph_.ops[i];
    if (op.primal_source < 0 || op.primal_source == op.out)
      fwd_fn_.push_back(resolve_forward_fn(op));
  }
  micro_.clear();
  micro_runs_.clear();
  fused_.clear();
  struct Pending {
    size_t ci;
    const Kernel* k;
    uint16_t opcode;
  };
  std::vector<Pending> pending;
  size_t run_start = 0;
  const auto close_run = [&] {
    if (pending.empty()) return;
    if (micro_.size() - run_start >= kMinMicroRun) {
      micro_runs_.push_back(MicroRun{static_cast<uint32_t>(run_start),
                                     static_cast<uint32_t>(micro_.size()),
                                     static_cast<uint32_t>(bwd_.size())});
      bwd_.push_back(BwdStep{nullptr, nullptr, nullptr});
      for (const Pending& p : pending)
        fused_.push_back(FusedOp{&ctx_[p.ci], p.k->cached_micro, p.opcode});
    } else {
      micro_.resize(run_start);
      for (const Pending& p : pending)
        bwd_.push_back(BwdStep{p.k->backward, &ctx_[p.ci], nullptr});
    }
    pending.clear();
  };
  for (size_t i = graph_.forward_only ? 0 : graph_.ops.size(); i-- > 0;) {
    const Op& op = graph_.ops[i];
    const Kernel& k = kernel(op.opcode);
    void (*b)(KernelCtx&) = k.backward;
    if (!b) continue;
    const size_t ci = has_shared_primals ? (size_t)primal_sources[i] : i;
    if (has_shared_primals && op.primal_source >= 0 &&
        op.primal_source != op.out && op.out2 < 0 && k.cached_micro) {
      const size_t before = micro_.size();
      if (pending.empty()) run_start = before;
      if (k.cached_micro(ctx_[ci], micro_)) {
        for (size_t m = before; m < micro_.size(); ++m)
          micro_[m].opcode = op.opcode;
        if (micro_.size() != before)
          pending.push_back(Pending{ci, &k, op.opcode});
        continue;
      }
      micro_.resize(before);
    }
    close_run();
    const int o2 = op.out2;
    const double* out2 =
        o2 >= 0 ? adjoints_.data() + adjoint_offsets[o2] : nullptr;
    bwd_.push_back(BwdStep{b, &ctx_[ci], out2});
  }
  close_run();
}

void Executor::refresh_micros_() {
  micro_.clear();
  for (const FusedOp& f : fused_) {
    const size_t before = micro_.size();
    f.fn(*f.ctx, micro_);
    for (size_t m = before; m < micro_.size(); ++m) micro_[m].opcode = f.opcode;
  }
}

KernelCtx Executor::make_ctx_(const Op& op, int64_t scratch_offset,
                              const std::vector<char>& written,
                              const std::vector<int64_t>& adjoint_offsets) {
  KernelCtx ctx;
  ctx.n_in = op.n_in;
  for (int i = 0; i < op.n_in; ++i) {
    const Slot& s = graph_.slots[op.in[i]];
    ctx.in[i] = Desc{slot_data_(op.in[i]), s.len};
  }
  const Slot& so = graph_.slots[op.out];
  ctx.out = Desc{slot_data_(op.out), so.len};
  if (op.out2 >= 0) {
    const Slot& s2 = graph_.slots[op.out2];
    ctx.out2 = Desc{slot_data_(op.out2), s2.len};
  }
  ctx.variant = op.variant;
  ctx.scratch = scratch_.empty() ? nullptr : scratch_.data() + scratch_offset;
  ctx.idata = op.idata;
  ctx.udata = op.udata;
  ctx.eval_state = &eval_state_;
  ctx.n_idata = op.n_idata;
  // A forward-only graph has no adjoints: every input reads as inactive and
  // the output adjoint has no storage.
  if (graph_.forward_only) {
    for (int i = 0; i < op.n_in; ++i)
      ctx.in_adj[i] = Desc{nullptr, graph_.slots[op.in[i]].len};
    ctx.out_adj_vec = Desc{nullptr, so.len};
    return ctx;
  }
  for (int i = 0; i < op.n_in; ++i) {
    const int si = op.in[i];
    const Slot& s = graph_.slots[si];
    const bool active = s.is_param || written[si];
    assert(!active || adjoint_offsets[si] >= 0);
    ctx.in_adj[i] =
        Desc{active ? adjoints_.data() + adjoint_offsets[si] : nullptr, s.len};
  }
  assert(adjoint_offsets[op.out] >= 0);
  const int64_t out_adj_off = adjoint_offsets[op.out];
  if (so.len == 1) ctx.out_adj = adjoints_[out_adj_off];
  ctx.out_adj_vec = Desc{adjoints_.data() + out_adj_off, so.len};
  if (op.out2 >= 0) {
    assert(adjoint_offsets[op.out2] >= 0);
    ctx.out2_adj = adjoints_[adjoint_offsets[op.out2]];
  }
  return ctx;
}

void Executor::detach_data_() {
  if (data_.use_count() == 1) return;
  auto replacement = std::make_shared<std::vector<double>>(*data_);
  data_ = std::move(replacement);
  // Bound contexts hold input pointers. No output can belong to data_.
  size_t forward = 0, cached = fwd_fn_.size();
  for (const Op& op : graph_.ops) {
    const size_t ci = op.primal_source >= 0 && op.primal_source != op.out
                          ? cached++
                          : forward++;
    for (int i = 0; i < op.n_in; ++i) {
      const int slot = op.in[i];
      if (data_offsets_[slot] >= 0) ctx_[ci].in[i].data = slot_data_(slot);
    }
  }
  refresh_micros_();
}

double* Executor::value_ptr(int slot) {
  if (!borrowed_.empty() && borrowed_[slot])
    throw std::logic_error("borrowed slot is read-only");
  if (data_offsets_[slot] >= 0) {
    detach_data_();
    data_pointer_exposed_ = true;
  }
  return slot_data_(slot);
}

void Executor::set_values(int slot, const double* data, size_t size) {
  if (slot < 0 || static_cast<size_t>(slot) >= graph_.slots.size() ||
      size > static_cast<uint64_t>(graph_.slots[slot].len))
    throw std::out_of_range("executor fill exceeds slot");
  if (!borrowed_.empty() && borrowed_[slot])
    throw std::logic_error("borrowed slot is read-only");
  if (data_offsets_[slot] >= 0) detach_data_();
  if (size) std::copy_n(data, size, slot_data_(slot));
}

void Executor::set_profile(bool on) {
  profile_ = on;
  if (on && prof_.empty()) prof_.resize(OP_COUNT_);
  if (on && ctx_opcodes_.empty()) {
    ctx_opcodes_.resize(ctx_.size());
    size_t forward = 0, cached = fwd_fn_.size();
    for (const Op& op : graph_.ops) {
      const size_t ci = op.primal_source >= 0 && op.primal_source != op.out
                            ? cached++
                            : forward++;
      ctx_opcodes_[ci] = op.opcode;
    }
  }
}

std::string Executor::profile_report() const {
  int64_t grand = 0;
  for (const auto& e : prof_) grand += e.fwd_ns + e.bwd_ns;
  if (grand == 0) return "";
  // Opcodes by total time, descending.
  std::vector<uint16_t> order;
  for (uint16_t op = 0; op < prof_.size(); ++op)
    if (prof_[op].calls > 0 || prof_[op].bwd_ns > 0) order.push_back(op);
  std::sort(order.begin(), order.end(), [&](uint16_t a, uint16_t b) {
    return prof_[a].fwd_ns + prof_[a].bwd_ns >
           prof_[b].fwd_ns + prof_[b].bwd_ns;
  });
  char line[160];
  std::string out;
  std::snprintf(line, sizeof line, "%-22s %10s %12s %12s %6s %12s\n", "opcode",
                "calls", "fwd ns", "bwd ns", "%", "elems");
  out += line;
  for (uint16_t op : order) {
    const ProfEntry& e = prof_[op];
    std::snprintf(line, sizeof line,
                  "%-22s %10lld %12lld %12lld %5.1f%% %12lld\n",
                  opcode_name(op), (long long)e.calls, (long long)e.fwd_ns,
                  (long long)e.bwd_ns,
                  100.0 * (double)(e.fwd_ns + e.bwd_ns) / (double)grand,
                  (long long)e.elems);
    out += line;
  }
  std::snprintf(line, sizeof line, "%-22s %10s %12lld ns total\n", "", "",
                (long long)grand);
  out += line;
  return out;
}

int64_t Executor::storage_bytes() const {
  const auto bytes = [](const auto& v) {
    return static_cast<int64_t>(v.size() * sizeof(v[0]));
  };
  return bytes(values_) + bytes(adjoints_) + bytes(scratch_) + bytes(ctx_) +
         bytes(fwd_fn_) + bytes(bwd_);
}

bool share_across_chains(const Executor& ex, int chains) {
  if (const char* forced = debug_env("STANLI_SHARE_WRITE_ARRAY"))
    return chains > 1 && forced[0] == '1';
  constexpr int64_t kCopyBudget = int64_t{1} << 30;
  return chains > 1 && ex.graph().forward_only &&
         (chains - 1) * ex.storage_bytes() >= kCopyBudget;
}

void Executor::run_forward_only() {
  run_forward_only(EvalState{nullptr, reduce_context_});
}

void Executor::run_forward_only(EvalState state) {
  reverse_ready_ = false;
  // These graphs cannot be reversed, but must retain their selected forward
  // arithmetic. Keep this distinct from log_prob<double>'s values_only mode.
  state.no_reverse = state.no_reverse || graph_.forward_only;
  struct RestoreState {
    EvalState& slot;
    EvalState previous;
    ~RestoreState() { slot = previous; }
  } restore{eval_state_, eval_state_};
  eval_state_ = state;
  // The profiled path keeps the opcode-keyed loop (attribution needs the
  // opcode anyway, and the timing calls dwarf dispatch cost), but it must
  // invoke the same bound function pointer as the fast path. The registry is
  // mutable for extension kernels; consulting it here would make profiling
  // change both variant specialization and post-bind kernel overrides.
  if (profile_) {
    const size_t np = fwd_fn_.size();
    for (size_t i = 0; i < np; ++i) {
      const uint16_t op = ctx_opcodes_[i];
      const auto t0 = std::chrono::steady_clock::now();
      fwd_fn_[i](ctx_[i]);
      const auto t1 = std::chrono::steady_clock::now();
      ProfEntry& e = prof_[op];
      ++e.calls;
      e.fwd_ns +=
          std::chrono::duration_cast<std::chrono::nanoseconds>(t1 - t0).count();
      e.elems += ctx_[i].out.len;
    }
    return;
  }
  // Unrolled by hand: four separate indirect-call sites predict
  // independently, and the loop bookkeeping amortizes. Measured against a
  // musttail-chained alternative: the unroll won (79-80% of the plain loop
  // vs 85-95%, and no kernel signature changes), so this is the whole of
  // "threaded dispatch" worth having.
  const size_t n = fwd_fn_.size();
  size_t i = 0;
  for (; i + 4 <= n; i += 4) {
    fwd_fn_[i](ctx_[i]);
    fwd_fn_[i + 1](ctx_[i + 1]);
    fwd_fn_[i + 2](ctx_[i + 2]);
    fwd_fn_[i + 3](ctx_[i + 3]);
  }
  for (; i < n; ++i) fwd_fn_[i](ctx_[i]);
}

double Executor::forward_value_only() {
  EvalState state{nullptr, reduce_context_};
  state.values_only = true;
  run_forward_only(state);
  assert(graph_.slots[graph_.result_slot].len == 1);
  return slot_data_(graph_.result_slot)[0];
}

double Executor::forward() {
  run_forward_only();
  assert(graph_.slots[graph_.result_slot].len == 1);
  reverse_ready_ = true;
  return slot_data_(graph_.result_slot)[0];
}

double Executor::gradient(double* grad_out) {
  if (graph_.forward_only)
    throw std::logic_error("a forward-only graph has no gradient");
  ++n_grad_evals_;
  const double v = forward();
  reverse(grad_out, 1.0);
  return v;
}

namespace {

template <class Step>
inline void run_bwd_step(const Step& s) {
  KernelCtx& ctx = *s.ctx;
  if (ctx.out_adj_vec.len == 1) ctx.out_adj = ctx.out_adj_vec.data[0];
  if (s.out2_adj) ctx.out2_adj = *s.out2_adj;
  s.fn(ctx);
}

inline void run_micro_range(const BwdMicro* m, const BwdMicro* end) {
  for (; m != end; ++m) run_bwd_micro(*m);
}

template <class Steps, class Runs>
[[gnu::noinline]] void reverse_dense_micro(const Steps& bwd, const Runs& runs,
                                           const std::vector<BwdMicro>& micro) {
  size_t run = 0;
  for (const auto& s : bwd) {
    if (s.fn) {
      run_bwd_step(s);
      continue;
    }
    const auto r = runs[run++];
    run_micro_range(micro.data() + r.begin, micro.data() + r.end);
  }
}

template <class Steps, class Runs>
[[gnu::noinline]] void reverse_sparse_micro(
    const Steps& bwd, const Runs& runs, const std::vector<BwdMicro>& micro) {
  const auto plain = [&](size_t i, const size_t end) {
    for (; i + 4 <= end; i += 4) {
      run_bwd_step(bwd[i]);
      run_bwd_step(bwd[i + 1]);
      run_bwd_step(bwd[i + 2]);
      run_bwd_step(bwd[i + 3]);
    }
    for (; i < end; ++i) run_bwd_step(bwd[i]);
  };
  size_t pos = 0;
  for (const auto& r : runs) {
    plain(pos, r.at);
    run_micro_range(micro.data() + r.begin, micro.data() + r.end);
    pos = r.at + 1;
  }
  plain(pos, bwd.size());
}

}  // namespace

void Executor::reverse(double* grad_out, double seed) {
  if (graph_.forward_only)
    throw std::logic_error("a forward-only graph has no gradient");
  if (!reverse_ready_)
    throw std::logic_error("reverse requires a fresh forward");
  reverse_ready_ = false;
  struct RestoreState {
    EvalState& state;
    EvalState previous;
    ~RestoreState() { state = previous; }
  } restore{eval_state_, eval_state_};
  eval_state_.reduce = reduce_context_;
  std::memset(adjoints_.data(), 0, sizeof(double) * adjoints_.size());
  assert(result_adjoint_offset_ >= 0);
  adjoints_[result_adjoint_offset_] = seed;
  if (profile_) {
    // Profile the exact bound backward plan. Each context belongs to ctx_,
    // so its index supplies opcode attribution without a second graph walk
    // or extra fields in the fast-path BwdStep layout.
    size_t run = 0;
    for (const BwdStep& step : bwd_) {
      if (!step.fn) {
        const MicroRun r = micro_runs_[run++];
        for (uint32_t m = r.begin; m < r.end; ++m) {
          const auto t0 = std::chrono::steady_clock::now();
          run_bwd_micro(micro_[m]);
          prof_[micro_[m].opcode].bwd_ns +=
              std::chrono::duration_cast<std::chrono::nanoseconds>(
                  std::chrono::steady_clock::now() - t0)
                  .count();
        }
        continue;
      }
      KernelCtx& ctx = *step.ctx;
      const size_t pi = static_cast<size_t>(step.ctx - ctx_.data());
      assert(pi < graph_.ops.size());
      if (ctx.out_adj_vec.len == 1) ctx.out_adj = ctx.out_adj_vec.data[0];
      if (step.out2_adj) ctx.out2_adj = *step.out2_adj;
      const auto t0 = std::chrono::steady_clock::now();
      step.fn(ctx);
      prof_[ctx_opcodes_[pi]].bwd_ns +=
          std::chrono::duration_cast<std::chrono::nanoseconds>(
              std::chrono::steady_clock::now() - t0)
              .count();
    }
    if (n_params_)
      std::memcpy(grad_out, adjoints_.data(), sizeof(double) * n_params_);
    return;
  }
  // Same unroll as the forward sweep (see run_forward_only).
  const auto step = [](const BwdStep& s) {
    KernelCtx& ctx = *s.ctx;
    // The only fields that move between evaluations: the scalar adjoints,
    // which kernels take by value.
    if (ctx.out_adj_vec.len == 1) ctx.out_adj = ctx.out_adj_vec.data[0];
    if (s.out2_adj) ctx.out2_adj = *s.out2_adj;
    s.fn(ctx);
  };
  const size_t nb = bwd_.size();
  if (!micro_runs_.empty()) {
    if (micro_.size() * 2 < nb)
      reverse_sparse_micro(bwd_, micro_runs_, micro_);
    else
      reverse_dense_micro(bwd_, micro_runs_, micro_);
    if (n_params_)
      std::memcpy(grad_out, adjoints_.data(), sizeof(double) * n_params_);
    return;
  }
  size_t i = 0;
  for (; i + 4 <= nb; i += 4) {
    step(bwd_[i]);
    step(bwd_[i + 1]);
    step(bwd_[i + 2]);
    step(bwd_[i + 3]);
  }
  for (; i < nb; ++i) step(bwd_[i]);
  if (n_params_)
    std::memcpy(grad_out, adjoints_.data(), sizeof(double) * n_params_);
}

}  // namespace stanli
